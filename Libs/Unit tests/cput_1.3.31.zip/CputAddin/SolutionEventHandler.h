#pragma once

__interface ISolutionEventHandler
{
	void Opened();
    void BeforeClosing();
	void AfterClosing();
	void QueryCloseSolution(VARIANT_BOOL* fCancel);
    void Renamed(BSTR OldName);
	void ProjectAdded(EnvDTE::Project* Project);
    void ProjectRemoved(EnvDTE::Project* Project);
    void ProjectRenamed(EnvDTE::Project* Project, BSTR OldName);
};

class SolutionEventHandler : public EnvDTE::_dispSolutionEvents
{
ut_private:	
	DWORD m_dwCookie;
	IConnectionPointPtr m_spCP;
	ISolutionEventHandler * m_pReceiver;
public:
	SolutionEventHandler(void);
	~SolutionEventHandler(void);

	BOOL Advise(EnvDTE80::DTE2 *pDTE, ISolutionEventHandler *pReceiver);
	void UnAdvise();
	
	//IUnknown
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObject);
    virtual ULONG STDMETHODCALLTYPE AddRef(void);
	virtual ULONG STDMETHODCALLTYPE Release(void);

	//IDispatch
	virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount(UINT *pctinfo);
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfo(UINT iTInfo, LCID lcid, ITypeInfo **ppTInfo);
    virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames(REFIID riid, LPOLESTR *rgszNames, UINT cNames, LCID lcid, DISPID *rgDispId);
    virtual HRESULT STDMETHODCALLTYPE Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS *pDispParams, VARIANT *pVarResult, EXCEPINFO *pExcepInfo, UINT *puArgErr);
};
