#pragma once
#include "ProjectCodeTypeTree.h"
#include "AddTracker.h"

class CUtGenerator
{
ut_private:
	//active project
	EnvDTE::ProjectPtr m_spOriginProject;
	//test project
	EnvDTE::ProjectPtr m_spTestProject;
	//if it's no empty than the precompile header that is used in m_spTestProject
	CAtlStringA m_strPrecompileHeader;
	//suffix for test group and test function names (should not be empty)
	CAtlStringW m_wstrSuffix;
	//group name for template a global function (should not be empty)
	CAtlStringW m_wstrGlobal;
public:
	CUtGenerator() : m_wstrSuffix(L"Test"), m_wstrGlobal(L"Global")
	{
	};

	//selects and creates a test project if it's needed, instruments code and makes test group
	BOOL GenerateTests(EnvDTE80::DTE2 * pDTE);
ut_private:
	BOOL GenerateUTProject(EnvDTE80::DTE2 * pDTE, LPCWSTR lpNewProjName);

	//recursively creates/opens files and creates/modifies unit test for checked items in rNode
	//void CreateUnitTests(CElementTree<CodeTreeItem> & rNode, CAddTracker* pAddTracker);

	void CreateUnitTestsRoot(CElementTree<CodeTreeItem> & rNode, CAddTracker* pAddTracker);
	void EnumUnitTestTree(CElementTree<CodeTreeItem> & rNode, CAddTracker* pAddTracker);

	//gets precompile header file name from m_spTestProject
	void GetPrecompileHeader(CAtlStringA & strPrecompileHeader);

	//fills in spMainFunction a wmain or main function
	static BOOL FindMainFunction(EnvDTE::CodeModel * pCodeModel, BOOL bIsAnsi, EnvDTE::CodeFunctionPtr & spMainFunction);

	static BOOL FindPrecompileHeaderInclude(EnvDTE::CodeElements * pCodeElements, EnvDTE::CodeFunction * pMainFunction, CComBSTR bstrPrecompileHeader, EnvDTE::CodeElementPtr & spPrecompileHeaderInclude);
	
	static BOOL GenerateMainTestCpp(const CAtlString & strTestProjectPath, const CAtlStringA & strPrecompileHeader, CAtlString & strMainTestCppFilePath);

	//The function is a sub part of GenerateUTProject
	//It uses m_spOriginProject and m_strPrecompileHeader to modify a precompile header
	//to add ut_protected and ut_private modifiers
	BOOL AddUtAccessModifiers();

	static BOOL FindFile(EnvDTE::ProjectItems * pProjectItems, const CComBSTR & bstrFileName, EnvDTE::ProjectItemPtr & spProjectItem);
};
