#pragma once

//is used do control Recursive Element Enumeration and return code from function
enum ReeRetCode
{
	Continue = 0,		//enumerate all elements
	NoSubEnumeration,	//do not enumerate members of code type
	AbortEnumeration,	//abort enumeration
};

//The interface has be inherited in order to use in RecursiveElementEnumeration
__interface IRecursiveEnumEvent
{
	//return TRUE to continue enumeration or FALSE to abort
	BOOL Element(EnvDTE::CodeElement * pElement);
};

//enumerates all code elements
BOOL RecursiveElementEnumeration( IN const EnvDTE::ProjectPtr & spProject, IRecursiveEnumEvent * pEvent);

//enumerates all code elements
BOOL RecursiveElementEnumeration( IN const EnvDTE::CodeElementsPtr & spCodeElements, IRecursiveEnumEvent * pEvent);

//defines an active VC project if any, return TRUE and set spActiveProject to found the project or FALSE otherwise
BOOL DefineActiveProject( IN const CComPtr<EnvDTE80::DTE2> & spDTE, OUT EnvDTE::ProjectPtr & spActiveProject);

//defines if spElement is pointer to class or structure that is a test group
BOOL IsElementTestGroup(const EnvDTE::CodeTypePtr & pCodeType);