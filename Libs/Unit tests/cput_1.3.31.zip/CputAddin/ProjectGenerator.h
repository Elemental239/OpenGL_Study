#pragma once


class CProjectGenerator
{
ut_private:
	CPath m_strTestProjectPath;

	//if project console application 
	//two main can be with /FORCE derictive but started only function in the most old modified file
	//user defined entry point can also be used but CLR has to be initialized manually
	//so to launch unit test _tmain is modified to launch test sequence
	BOOL m_bIsModifyMainNeeded;
	GUID m_guidProj;
	BOOL m_bIsAnsi;

public:
	CProjectGenerator(void);
	~CProjectGenerator(void);

	//copies and changes existing project to test one
	BOOL MakeTestProject(LPCWSTR lpTemplatePath, LPCWSTR lpTestProjectName);

	inline CAtlString GetTestProjectPath() const { return m_strTestProjectPath.m_strPath; }
	inline BOOL IsModifyMainNeeded() const { return m_bIsModifyMainNeeded; }
	inline BOOL IsAnsi() const { return m_bIsAnsi; }
ut_private:
	//Fills m_strTestProjectPath by combination path from lpTemplatePath and new file name lpTestProjectName
	BOOL MakeTestProjectPath(LPCWSTR lpTemplatePath, LPCWSTR lpTestProjectName);


	BOOL ChangeCompilerConfiguration(IXMLDOMElementPtr spVisualStudioProject, BOOL & bIsConsole);

	//changes Preprocessor Directive Line to make console application
	//bWasConsole returns TRUE if Preprocessor Directive Line has _CONSOLE directive defined
	//returns TRUE if there has been any changes
	static BOOL ChangePreprocessorDirectiveToConsole(IN OUT CAtlStringW & wstr, OUT BOOL & bWasConsole);

	//changes Additional Include Directories property to make all relative paths look one folder higher
	//also add if needed ".." so any way source is modified after all.
	static void ModifyAdditionalIncludeDirectories(IN OUT CAtlStringW & wstr);
	
	//modifies project configurations to make them executable
	static BOOL ModifyLinkerOptions(IXMLDOMElementPtr & spVisualStudioProject);

	//modifies paths of all files in the project to make them available from the UnitTest subfolder
	static BOOL ModifyPaths(IXMLDOMElementPtr & spVisualStudioProject);

	//removes hhp, hhc, hhk files from the project and modify the resource.h file options
	static void RemoveHlpFiles(IXMLDOMElementPtr & spVisualStudioProject);

	//removes Post build events
	static void RemovePostBuildEvents(IXMLDOMElementPtr & spVisualStudioProject);

	//reset output and intermediates directories for all configurations
	static void DefineOutputAndIntermediateDir(IXMLDOMElementPtr & spVisualStudioProject);
};
