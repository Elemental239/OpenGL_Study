#ifndef __ITESTRUNNOTIFICATION_H__
#define __ITESTRUNNOTIFICATION_H__

#include "..\Common.h"
#include "..\TransData.h"

__interface ITestRunNotification
{
	void StartNotification(DWORD dwTestAppProcessId);
    void TestSet(TestPackTransData & rTestSet);
    void GroupStartNotification(DWORD nGroupParam);
    void TestStartNotification(DWORD nGroupParam, DWORD nTestParam);
    void TestEndNotification(DWORD nGroupParam, DWORD nTestParam, ERunStatus eRunStatus, __time64_t tDuration, LPCWSTR lpReport);
    void GroupEndNotification(DWORD nGroupParam, ERunStatus eRunStatus, __time64_t tDuration, LPCWSTR lpReport);
    void EndNotification();

	void AbortNotification();
};

__interface IExchangeControl
{
	void TestAppNotify(WPARAM wParam, LPARAM lParam);
	void Start(EnvDTE::Project* pCurSelProject, BOOL bDebug);
};

#endif