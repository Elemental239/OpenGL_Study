#pragma once

class CAddTracker
{
public:
	VCCodeModelLibrary::VCCodeFunctionPtr m_spNewTestFunc;
	CAtlStringW	m_wstrFile;

	CAddTracker(void);
	~CAddTracker(void);

	inline BOOL IsInit() const { return ( m_wstrFile.GetLength() ) || ( m_spNewTestFunc ); };

	void AddTestGroup(LPCWSTR lpFile);
	void AddTestFunc(VCCodeModelLibrary::VCCodeFunction* pNewTestFunc);
};
