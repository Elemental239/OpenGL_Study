#pragma once

//replace comments and Test Literals with ' '
void ReplaceCommentAndTextLiteral(IN const CAtlStringW & rSourceCode, OUT CAtlStringW & rOutput);

//defines position of lpLexeme in wstr, starting from nStart 
//that has not apphanum symbols immediately before and after the lexeme
//return find index or -1 otherwise
int FindLexeme(IN const CAtlStringW & wstr, IN LPCWSTR lpLexeme, IN int nStart = 0);
