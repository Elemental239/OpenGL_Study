//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AddIn.rc
//
#define IDS_PROJNAME                    100
#define IDR_ADDIN                       101
#define IDS_REFRESH                     101
#define IDR_CONNECT                     102
#define IDS_RUNALL                      102
#define IDD_INSTRUMENTATIONWIZARD       103
#define IDS_RUNCHECKED                  103
#define IDD_NEWTEST                     103
#define IDS_DEBUGALL                    104
#define IDR_TESTRUNNERWND               105
#define IDS_DEBUGCHECKED                105
#define IDC_TOOLBAR                     106
#define IDS_UNABLETORETRIEVEMAINBODY    106
#define ID_REFRESH                      107
#define IDS_STRING107                   107
#define IDS_WARNING                     107
#define ID_RUNALL                       108
#define ID_RUNCHECKED                   109
#define ID_DEBUGALL                     110
#define ID_DEBUGCHECKED                 111
#define IDR_TESTTREEPOPUP               130
#define IDC_CODEMODELTREE               201
#define IDD_TESTRUNNERWND               201
#define IDC_COMBO1                      202
#define IDC_UTPROJECTNAME               202
#define IDC_CB_TESTPROJECTS             202
#define IDC_UTPROJECTNAME2              203
#define IDC_PROJECTNAME                 203
#define IDB_STATUSLIST                  207
#define IDB_TESTRUNNERTAB               208
#define IDC_TESTRUNLIST                 211
#define IDC_BT_REFRESH                  212
#define IDC_BT_RUNALL                   213
#define IDC_BT_RUNCHECKED               214
#define IDC_BT_DEBUGALL                 215
#define IDC_BT_DEBUGCHECKED             216
#define IDC_BT_SHOWTESTPROJECT          218
#define IDC_BT_HIDETESTPROJECTS         218
#define IDC_CHECK1                      219
#define IDC_BT_HIDEABSTRACTCLASSES      219
#define IDC_BT_HIDEABSTRACTCLASSES2     220
#define IDC_BT_HIDENAMESPACES           220
#define ID_TESTTREEPOPUP_DISABLE        32772
#define ID_TESTTREEPOPUP_CHECK          32773
#define ID_TESTTREEPOPUP_UNCHECKALL     32774
#define ID_TESTTREEPOPUP_ENABLE         32775
#define ID_TESTTREEPOPUP_CHECKALL       32776
#define ID_TESTTREEPOPUP_UNCHECK        32777
#define ID_TESTTREEPOPUP_COPY           32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        209
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         220
#define _APS_NEXT_SYMED_VALUE           116
#endif
#endif
