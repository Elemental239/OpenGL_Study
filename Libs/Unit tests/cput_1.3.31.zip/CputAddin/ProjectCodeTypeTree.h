#pragma once
#include "DteFunctions.h"
#include "ElementTree.h"


struct CodeTreeItem
{
	CAtlString Name;
	BOOL Checked;
	BOOL Abstract;
	EnvDTE::vsCMElement eKind;

	union {
		EnvDTE::vsCMFunction eFunctionKind;
	} ElementData;


	CodeTreeItem() :
	Checked(FALSE), Abstract(FALSE), eKind(EnvDTE::vsCMElementOther)
	{
	}

	CodeTreeItem(const CodeTreeItem & item) :
	Name(item.Name), Checked(item.Checked), Abstract(item.Abstract),
		eKind(item.eKind)
	{
		switch(item.eKind)
		{
		case EnvDTE::vsCMElementFunction:
			ElementData.eFunctionKind = item.ElementData.eFunctionKind;
			break;
		}
	}

	bool operator ==(const CodeTreeItem & item) const
	{
		return (Name == item.Name) && (eKind == item.eKind);
	}
};


class CProjectCodeTypeTree :
	public IRecursiveEnumEvent,
	public CElementTree<CodeTreeItem>
{
public:
	//IRecursiveEnumEvent
	virtual BOOL Element(EnvDTE::CodeElement * pElement);
ut_private:
	void AddElement(EnvDTE::CodeElement * pElement);
	static void Walk(EnvDTE::CodeElement * pElement, CAtlList<CodeTreeItem> & rList);
	static void Form(const CAtlList<CodeTreeItem> & rList, POSITION pos, CElementTree<CodeTreeItem> & Node);
};