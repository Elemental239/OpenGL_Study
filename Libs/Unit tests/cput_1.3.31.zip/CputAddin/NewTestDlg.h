// CNewTestDlg.h : Declaration of the CNewTestDlg

#pragma once

#include "resource.h"       // main symbols
#include "ProjectCodeTypeTree.h"

// CNewTestDlg

class CNewTestDlg : 
	public CAxDialogImpl<CNewTestDlg>
{
ut_private:
	CWindow m_wndTree;
	CWindow m_wndProjCombo;
	CWindow m_wndUtProjCombo;
	CWindow m_wndBtHideTestProjects;
	CWindow m_wndBtHideAbstractClasses;
	CWindow m_wndBtHideNamespaces;

	CProjectCodeTypeTree m_csElementTree;
	CAtlStringW m_wstrTestProjectName;

	CAtlArray<EnvDTE::ProjectPtr> m_aProjects;
	CAtlArray<EnvDTE::ProjectPtr> m_aTestProjects;

	EnvDTE::ProjectPtr m_spOriginalProject;
	EnvDTE::ProjectPtr m_spTestProject;

	const CComPtr<EnvDTE80::DTE2> m_spDTE;
	const CAtlStringW m_wstrSuffix;

	BOOL m_bHideTestProjects;
	BOOL m_bHideAbstractClasses;
	BOOL m_bHideNamespaces;

public:
	CNewTestDlg(EnvDTE80::DTE2 * pDTE, LPCWSTR lpSuffix);
	~CNewTestDlg();

	enum { IDD = IDD_NEWTEST };

BEGIN_MSG_MAP(CNewTestDlg)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOK)
	COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnClickedCancel)
	COMMAND_HANDLER(IDC_PROJECTNAME, CBN_SELCHANGE, OnCbnSelchangeProjectname)
	COMMAND_HANDLER(IDC_BT_HIDETESTPROJECTS, BN_CLICKED, OnBnClickedBtHidetestprojects)
	COMMAND_HANDLER(IDC_BT_HIDEABSTRACTCLASSES, BN_CLICKED, OnBnClickedHideAbstractClasses)
	COMMAND_HANDLER(IDC_BT_HIDENAMESPACES, BN_CLICKED, OnBnClickedHideNamespaces)
	CHAIN_MSG_MAP(CAxDialogImpl<CNewTestDlg>)
END_MSG_MAP()

// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnClickedOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

	LRESULT OnClickedCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}

	//Forms m_csElementTree and fills m_wndTree
	void FillTree();

	//Fills recursively content of m_wndTree with m_rElementTree content
	void FillTree(CElementTree<CodeTreeItem> & pNode, HTREEITEM hParent = NULL);
	//Defines projects in solution that does not have the _UT predefined directive
	void FillProjectCombo();
	//Sets recursively Checked properties for m_rElementTree content by state of three item check box
	void AcceptChangesTree(HTREEITEM hParent = NULL);

	//defines is the new or exsting project should be used and fills m_wstrTestProjectName, m_wstrTestProjectPath
	void AcceptChangesProjectCombo();

	//returns the selected  original project
	inline EnvDTE::ProjectPtr GetOriginalProject() const { return m_spOriginalProject; }

	//returns TRUE if a test project is not exist
	inline BOOL IsNewTestProject() const { return m_spTestProject == NULL; }
	//returns name of a test project
	inline CAtlStringW GetTestProjectName() const { return m_wstrTestProjectName; }
	//returns path to an existing test project
	inline EnvDTE::ProjectPtr GetTestProject() const { return m_spTestProject; }
	//returns element's tree
	inline CElementTree<CodeTreeItem> & GetTree() { return m_csElementTree; }
	//notification on change selection in project combo box
	LRESULT OnCbnSelchangeProjectname(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedBtHidetestprojects(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);

	LRESULT OnBnClickedHideAbstractClasses(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedHideNamespaces(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
ut_private:
	void FillTestProjectCombo();
};


