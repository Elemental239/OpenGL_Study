#pragma once
#include "ITestRunNotification.h"

class CTestAppRunNotification
{
	CHandle m_hEvent;
	CHandle m_hMmf;
	wchar_t m_wsz[30];
	
	ITestRunNotification *	m_pITestRunNotification;
public:
	CTestAppRunNotification(void);
	~CTestAppRunNotification(void);

	void Init(ITestRunNotification * pITestRunNotification);
	void Reset();
	void Dispose();

	void TestAppNotify(WPARAM wParam, LPARAM lParam);

ut_private:

	void Abort();

	void StartNotification(DWORD dwTestAppProcessId);
	void TestSet(DWORD nSize);
	void GroupStartNotification(DWORD nSize);
	void TestStartNotification(DWORD nSize);
	void TestEndNotification(DWORD nSize);
	void GroupEndNotification(DWORD nSize);
	void EndNotification();

};
