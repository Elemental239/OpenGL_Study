#pragma once

class CInstallationHelper
{
ut_private:
	CAtlString	m_strUserTypeFilePath;
	CAtlString	m_strStudioRootFolder;
	CAtlString	m_strLibFileName;

	enum VsVersion
	{
		vsV8 = 8,
		vsV9 = 9
	};

	CInstallationHelper(VsVersion eVsVersion);
	~CInstallationHelper(void);

	void RegisterUtUserType();
	void UnregisterUtUserType();

	BOOL ReadUserTypeFile(OUT CAtlStringW & wstr, OUT BOOL & bIsUnicode);
	BOOL WriteUserTypeFile(IN const CAtlStringW & wstr, IN BOOL bIsUnicode);

	//finds in the running directory utassert.h, uttestbase.h abd cputlib.lib files
	//and places them in visual studio's include and lib folders
	void MoveLibFiles();

	//removes utassert.h, uttestbase.h abd cputlib.lib from visual studio's folders
	void RemoveLibFiles();
public:
	static void Install();
	static void Uninstall();

};
