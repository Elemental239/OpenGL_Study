#pragma once
#include "ProjectCodeTypeTree.h"
#include "AddTracker.h"

class CTestFunctionHandler
{
ut_private:
	//test group class
	VCCodeModelLibrary::VCCodeClassPtr m_spTestGroup;
	//test function name
	CComBSTR m_bstrTestFunctionName;
	//source file path
	CComBSTR m_bstrSourceFilePath;

	EnvDTE::TextPointPtr m_spUtFuncTableStart, m_spUtFuncTableEnd;
	
	CAddTracker * m_pAddTracker;
public:
	CTestFunctionHandler(const EnvDTE::CodeElementPtr & spTestGroupElement, CAddTracker * pAddTracker);
	~CTestFunctionHandler(void);

	BOOL Add(LPCWSTR lpTemplate);

	void Add(CElementTree<CodeTreeItem> & rNode);

ut_private:
	//defines a name for a future test function and stores it in m_bstrTestFunctionName
	BOOL DefineTestFunctionName(LPCWSTR lpTemplate);
	//finds the start point of table of unit test function and stores it in m_spTableEditPoint
	BOOL DefineUtFuncTable();
	
	BOOL AddNewTestFunction();

	BOOL AddEntryInUtFuncTable();

	BOOL AddEntryInUtFuncTable(LPCWSTR lpTableContent);
};
