// CNewTestDlg.cpp : Implementation of CNewTestDlg

#include "stdafx.h"
#include "NewTestDlg.h"
#include "MultiLinePropertyHandler.h"
#include "DteFunctions.h"

// CNewTestDlg
CNewTestDlg::CNewTestDlg(EnvDTE80::DTE2 * pDTE, LPCWSTR lpSuffix) :
	m_spDTE(pDTE), m_wstrSuffix(lpSuffix), 
	m_bHideTestProjects(TRUE),	m_bHideAbstractClasses(TRUE), m_bHideNamespaces(TRUE)
{

}

CNewTestDlg::~CNewTestDlg()
{
}

LRESULT CNewTestDlg::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CAxDialogImpl<CNewTestDlg>::OnInitDialog(uMsg, wParam, lParam, bHandled);

	m_wndTree = GetDlgItem(IDC_CODEMODELTREE);
	m_wndProjCombo = GetDlgItem(IDC_PROJECTNAME);
	m_wndUtProjCombo = GetDlgItem(IDC_UTPROJECTNAME);
	m_wndBtHideTestProjects = GetDlgItem(IDC_BT_HIDETESTPROJECTS);
	m_wndBtHideAbstractClasses = GetDlgItem(IDC_BT_HIDEABSTRACTCLASSES);
	m_wndBtHideNamespaces = GetDlgItem(IDC_BT_HIDENAMESPACES);
	
	m_wndBtHideTestProjects.SendMessage(BM_SETCHECK, m_bHideTestProjects ? BST_CHECKED : BST_UNCHECKED, 0);
	m_wndBtHideAbstractClasses.SendMessage(BM_SETCHECK, m_bHideAbstractClasses ? BST_CHECKED : BST_UNCHECKED, 0);
	m_wndBtHideNamespaces.SendMessage(BM_SETCHECK, m_bHideNamespaces ? BST_CHECKED : BST_UNCHECKED, 0);

	FillProjectCombo();
	FillTree();

	bHandled = TRUE;
	return 1;  // Let the system set the focus
}

LRESULT CNewTestDlg::OnClickedOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	AcceptChangesProjectCombo();
	AcceptChangesTree();
	
	if ((m_spOriginalProject) && (m_wstrTestProjectName.GetLength()))
	{
		EndDialog(wID);
	}

	return 0;
}

void CNewTestDlg::FillTree()
{
	m_csElementTree.RemoveChildren();
	TreeView_DeleteAllItems(m_wndTree.m_hWnd);

	if ((m_spOriginalProject) &&
		RecursiveElementEnumeration(m_spOriginalProject, &m_csElementTree))
	{
		FillTree(m_csElementTree, NULL);
	}
}

void CNewTestDlg::FillTree(CElementTree<CodeTreeItem> & rNode, HTREEITEM hParent)
{
	TVINSERTSTRUCT st;
	POSITION pos = rNode.GetHeadPosition();
	st.hParent = hParent;
	st.hInsertAfter = TVI_LAST;
	st.item.mask = TVIF_CHILDREN | TVIF_TEXT | TVIF_PARAM;
	while (pos)
	{
		CElementTree<CodeTreeItem> & rChild = rNode.GetNext(pos);
		CodeTreeItem & rCodeTreeItem = rChild.GetValue();
		if ((m_bHideAbstractClasses) && (rCodeTreeItem.Abstract))
			continue; //currently even if an abstract class contains a not abstract class all classes is not shown this mode

		HTREEITEM hTreeItem;
		if ((rCodeTreeItem.eKind == EnvDTE::vsCMElementNamespace) && (m_bHideNamespaces))
		{
			hTreeItem = hParent;
		} else
		{
			st.item.cchTextMax = rCodeTreeItem.Name.GetLength();
			st.item.pszText = const_cast<LPTSTR>(rCodeTreeItem.Name.GetString());
			st.item.cChildren = rChild.ChildrenCount() ? 1 : 0;
			st.item.lParam = reinterpret_cast<LPARAM>(&rCodeTreeItem);
			hTreeItem = (HTREEITEM)m_wndTree.SendMessage(TVM_INSERTITEM, 0, (LPARAM)&st);
		}

		if (rChild.ChildrenCount())
		{
			FillTree(rChild, hTreeItem);
		}
	}
}

void CNewTestDlg::FillProjectCombo()
{
	long nCount = 0;
	EnvDTE::ProjectPtr spCurSelProj;
	BOOL bProjectSelected = FALSE;
	CComBSTR bstr, bstrCurSelName, bstrCurSelUniqueName;
	EnvDTE::_SolutionPtr spSolution;

	size_t nCurSel = m_wndProjCombo.SendMessage(CB_GETCURSEL);
	if ((nCurSel >= 0) && (m_aProjects.GetCount() > nCurSel))
	{
		spCurSelProj = m_aProjects.GetAt(nCurSel);
	}
	else
	{
		DefineActiveProject(m_spDTE, spCurSelProj);
	}

	if (spCurSelProj)
	{
		spCurSelProj->get_Name(&bstrCurSelName);
		spCurSelProj->get_UniqueName(&bstrCurSelUniqueName);
	}

	m_aProjects.RemoveAll();
	m_aTestProjects.RemoveAll();

	m_wndProjCombo.SendMessage(CB_RESETCONTENT);
	
	if (SUCCEEDED(m_spDTE->get_Solution(&spSolution)) &&
		SUCCEEDED(spSolution->get_Count(&nCount)))
	{
		CComVariant vtVCCLCompilerTool(L"VCCLCompilerTool");
		for(CComVariant vt(1);vt.lVal <= nCount; ++vt.lVal)
		{
			EnvDTE::ProjectPtr spProject;
			EnvDTE::PropertiesPtr spProperties;
			VCProjectEngineLibrary::VCProjectPtr spVCProject;
			IDispatchPtr spDispatch;
			VCProjectEngineLibrary::IVCCollectionPtr spVCConfigurations, spTools;
			VCProjectEngineLibrary::VCConfigurationPtr spVCConfiguration;
			VCProjectEngineLibrary::VCCLCompilerToolPtr spVCCLCompilerTool;
			CComBSTR bstrName, bstrUniqueName;

			if (SUCCEEDED(spSolution->Item(vt, &spProject)) &&
				SUCCEEDED(spProject->get_Object(&spDispatch)) &&
				(spVCProject = spDispatch) && //C++ project
				SUCCEEDED(spVCProject->get_Configurations(&spDispatch)) &&
				(spVCConfigurations = spDispatch) &&
				SUCCEEDED(spVCConfigurations->Item(CComVariant(1), &spDispatch)) && //use first configuration
				(spVCConfiguration = spDispatch) &&
				SUCCEEDED(spVCConfiguration->get_Tools(&spDispatch)) &&
				(spTools = spDispatch) &&
				SUCCEEDED(spTools->Item(vtVCCLCompilerTool, &spDispatch)) &&
				(spVCCLCompilerTool = spDispatch) &&
				SUCCEEDED(spVCCLCompilerTool->get_PreprocessorDefinitions(&bstr)) &&
				SUCCEEDED(spProject->get_Name(&bstrName)) &&
				SUCCEEDED(spProject->get_UniqueName(&bstrUniqueName)))
			{
				CMultiLinePropertyHandler cs(bstr);
				BOOL bIsTestProject = cs.IsDefined(L"_UT");

				if ((bIsTestProject == FALSE) || (m_bHideTestProjects == FALSE))
				{
#ifdef _UNICODE
					m_wndProjCombo.SendMessage(CB_ADDSTRING, 0, (LPARAM)bstrName.m_str);
#else
					CAtlString str(bstrName);
					m_wndProjCombo.SendMessage(CB_ADDSTRING, 0, (LPARAM)str.GetString());
#endif
					size_t tCur = m_aProjects.Add(spProject);
			
					if (FALSE == bProjectSelected)
					{
						if (bstrCurSelUniqueName.Length() == 0)
						{ //select any
							m_spOriginalProject = spProject;
							bstrCurSelName = bstrName;
							m_wndProjCombo.SendMessage(CB_SETCURSEL, tCur);
							bProjectSelected = TRUE;
						} else if (bstrCurSelUniqueName == bstrUniqueName)
						{ //given origin project has been found
							m_wndProjCombo.SendMessage(CB_SETCURSEL, tCur);
							bProjectSelected = TRUE;
						}
					}
				} //if ((bIsTestProject == FALSE) || (m_bHideTestProjects == FALSE))

				if (bIsTestProject)
				{
					m_aTestProjects.Add(spProject);
				} //if (bIsTestProject)
			}
		} //for(CComVariant vt(1);vt.lVal <= nCount; ++vt.lVal)
	}

	if ((bProjectSelected == FALSE) && (m_wndProjCombo.SendMessage(CB_GETCOUNT) > 0))
	{
		m_wndProjCombo.SendMessage(CB_SETCURSEL);
	}

	if (m_aProjects.GetCount())
		m_spOriginalProject = m_aProjects.GetAt(m_wndProjCombo.SendMessage(CB_GETCURSEL));

	FillTestProjectCombo();
}

void CNewTestDlg::AcceptChangesTree(HTREEITEM hParent)
{
	TVITEM st;
	st.mask = TVIF_HANDLE | TVIF_PARAM | TVIF_STATE;
	st.stateMask = TVIS_STATEIMAGEMASK;
	st.hItem = (HTREEITEM)m_wndTree.SendMessage(TVM_GETNEXTITEM, TVGN_CHILD, (LPARAM)hParent);
	while (st.hItem)
	{
		if (m_wndTree.SendMessage(TVM_GETITEM, 0, (LPARAM)&st))
		{
			CodeTreeItem * pCodeTreeItem = reinterpret_cast<CodeTreeItem*>(st.lParam);
			pCodeTreeItem->Checked = ((BOOL)(st.state >> 12) -1); // from winctrl2.cpp
		}

		AcceptChangesTree(st.hItem);
		
		st.hItem = (HTREEITEM)m_wndTree.SendMessage(TVM_GETNEXTITEM, TVGN_NEXT, (LPARAM)st.hItem);
	}
}

void CNewTestDlg::AcceptChangesProjectCombo()
{
	m_wndUtProjCombo.GetWindowTextW(m_wstrTestProjectName);
	m_spTestProject = NULL;

	//check in case the exact name of one of existing test projects was typed
	LRESULT lResult = m_wndUtProjCombo.SendMessage(CB_FINDSTRINGEXACT, -1, (LPARAM)(LPCTSTR)CW2T(m_wstrTestProjectName));
	if (lResult != CB_ERR)
	{
		m_spTestProject = m_aTestProjects.GetAt(m_wndUtProjCombo.SendMessage(CB_GETITEMDATA, lResult, 0));
	}
	
}
LRESULT CNewTestDlg::OnCbnSelchangeProjectname(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& bHandled)
{
	m_spOriginalProject = m_aProjects.GetAt(m_wndProjCombo.SendMessage(CB_GETCURSEL));
	FillTree();
	FillTestProjectCombo();

	bHandled = TRUE;
	return 0;
}

LRESULT CNewTestDlg::OnBnClickedBtHidetestprojects(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& bHandled)
{
	bHandled = TRUE;
	m_bHideTestProjects = BST_CHECKED == m_wndBtHideTestProjects.SendMessage(BM_GETCHECK);

	size_t nCurSel = m_wndProjCombo.SendMessage(CB_GETCURSEL);
	CComBSTR bstrCurSelUniqueNameBefore;
	CComBSTR bstrCurSelUniqueNameAfter;
	if ((nCurSel >= 0) && (m_aProjects.GetCount() > nCurSel))
		m_aProjects.GetAt(nCurSel)->get_UniqueName(&bstrCurSelUniqueNameBefore);

	FillProjectCombo();

	nCurSel = m_wndProjCombo.SendMessage(CB_GETCURSEL);
	if ((nCurSel >= 0) && (m_aProjects.GetCount() > nCurSel))
		m_aProjects.GetAt(nCurSel)->get_UniqueName(&bstrCurSelUniqueNameAfter);

	if (bstrCurSelUniqueNameBefore != bstrCurSelUniqueNameAfter)
		FillTree();

	return 0;
}

LRESULT CNewTestDlg::OnBnClickedHideAbstractClasses(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& bHandled)
{
	bHandled = TRUE;
	m_bHideAbstractClasses = BST_CHECKED == m_wndBtHideAbstractClasses.SendMessage(BM_GETCHECK);
	
	TreeView_DeleteAllItems(m_wndTree.m_hWnd);
	FillTree(m_csElementTree, NULL);

	return 0;
}

LRESULT CNewTestDlg::OnBnClickedHideNamespaces(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& bHandled)
{
	bHandled = TRUE;
	m_bHideNamespaces = BST_CHECKED == m_wndBtHideNamespaces.SendMessage(BM_GETCHECK);
	
	TreeView_DeleteAllItems(m_wndTree.m_hWnd);
	FillTree(m_csElementTree, NULL);

	return 0;
}

void CNewTestDlg::FillTestProjectCombo()
{
	m_wndUtProjCombo.SendMessage(CB_RESETCONTENT);

	CComBSTR bstrUniq, bstrCurSelName;
	if ((m_spOriginalProject) && 
		SUCCEEDED(m_spOriginalProject->get_UniqueName(&bstrUniq)) && 
		SUCCEEDED(m_spOriginalProject->get_Name(&bstrCurSelName))
		)
	{
		for (size_t t = 0; t < m_aTestProjects.GetCount(); ++t)
		{
			CComBSTR bstr, bstrName;
			IDispatchPtr spDispat�h;
			VCProjectEngineLibrary::VCProjectPtr spVCProject;
			if (SUCCEEDED(m_aTestProjects.GetAt(t)->get_Object(&spDispat�h)) &&
				(spVCProject = spDispat�h) &&
				SUCCEEDED(spVCProject->get_keyword(&bstr)) &&
				(bstr == bstrUniq) &&
				SUCCEEDED(spVCProject->get_Name(&bstrName))
				)
			{
				LRESULT lr = m_wndUtProjCombo.SendMessage(CB_ADDSTRING, 0, (LPARAM)(LPCTSTR)CW2T(bstrName.m_str));
				m_wndUtProjCombo.SendMessage(CB_SETITEMDATA, lr, t);
			}
		}
	
		if (m_wndUtProjCombo.SendMessage(CB_GETCOUNT) > 0)
		{
			m_wndUtProjCombo.SendMessage(CB_SETCURSEL);
		} 
		else if (bstrCurSelName.Length())
		{
			CAtlString str(bstrCurSelName);
			str.Append(m_wstrSuffix.GetString());
			m_wndUtProjCombo.SendMessage(WM_SETTEXT, 0, (LPARAM)str.GetString());
		}
	}
}