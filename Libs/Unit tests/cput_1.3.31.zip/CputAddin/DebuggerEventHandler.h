#pragma once

__interface IDebuggerEventHandler
{
	void ContextChanged(EnvDTE::Process* pProcess , EnvDTE::Program* pProgram, EnvDTE::Thread* pThread, EnvDTE::StackFrame* pStackFrame);
	void EnterBreakMode(EnvDTE::dbgEventReason dbgEventReason, EnvDTE::dbgExecutionAction* pdbgExecutionAction);
    void EnterDesignMode(EnvDTE::dbgEventReason dbgEventReason);
    void EnterRunMode(EnvDTE::dbgEventReason dbgEventReason);
    void ExceptionNotHandled(BSTR bstrExceptionType, BSTR bstrName, int nCode, BSTR bstrDescription, EnvDTE::dbgExecutionAction* pdbgExecutionAction);
    void ExceptionThrown(BSTR bstrExceptionType, BSTR bstrName, int nCode, BSTR bstrDescription, EnvDTE::dbgExecutionAction* pdbgExecutionAction);
};

class DebuggerEventHandler : public EnvDTE::_dispDebuggerEvents
{
ut_private:	
	DWORD m_dwCookie;
	IConnectionPointPtr m_spCP;
	IDebuggerEventHandler *m_pReceiver;
public:
	DebuggerEventHandler(void);
	~DebuggerEventHandler(void);

	BOOL Advise(EnvDTE80::DTE2 *pDTE, IDebuggerEventHandler *pReceiver);
	void UnAdvise();
	
	//IUnknown
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObject);
    virtual ULONG STDMETHODCALLTYPE AddRef(void);
	virtual ULONG STDMETHODCALLTYPE Release(void);

	//IDispatch
	virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount(UINT *pctinfo);
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfo(UINT iTInfo, LCID lcid, ITypeInfo **ppTInfo);
    virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames(REFIID riid, LPOLESTR *rgszNames, UINT cNames, LCID lcid, DISPID *rgDispId);
    virtual HRESULT STDMETHODCALLTYPE Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS *pDispParams, VARIANT *pVarResult, EXCEPINFO *pExcepInfo, UINT *puArgErr);

};
