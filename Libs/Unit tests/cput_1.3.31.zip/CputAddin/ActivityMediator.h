#pragma once
#include "SolutionEventHandler.h"
#include "DebuggerEventHandler.h"
#include "BuildEventHandler.h"
#include "TestRunnerWnd.h"
#include "TestAppRunNotification.h"

class CActivityMediator : 
	public ISolutionEventHandler,
	public IDebuggerEventHandler,
	public IBuildEventHandler,
	public IExchangeControl
{
ut_private:
	CComPtr<EnvDTE80::DTE2> m_spDTE;
	CComPtr<EnvDTE::AddIn> m_spAddInInstance;

	HBITMAP	m_hTabBmp;
	EnvDTE::WindowPtr m_spWindow;
	CTestRunnerWnd * m_pTestRunnerWnd;

	SolutionEventHandler m_csSolutionEventHandler;
	DebuggerEventHandler m_csDebuggerEventHandler;
	BuildEventHandler m_csBuildEventHandler;

	CTestAppRunNotification m_csTestAppRunNotification;

	BOOL	m_bAll;
	CComVariant	m_vtPrevStartupProj;
	BOOL m_bSwitchToOutput;

	VARIANT_BOOL m_vbOutputHideStatus;

public:
	CActivityMediator(void);
	~CActivityMediator(void);

	//------------------------------------------
	void Init(EnvDTE80::DTE2 *pDTE, EnvDTE::AddIn *pAddInInstance);

	void TestWizard();

	void ShowTestRunnerWnd();

	void Dispose();
	//------------------------------------------

ut_private:
	//ISolutionEventHandler methods
	void Opened();
    void BeforeClosing();
	void AfterClosing();
	void QueryCloseSolution(VARIANT_BOOL* fCancel);
    void Renamed(BSTR OldName);
	void ProjectAdded(EnvDTE::Project* Project);
    void ProjectRemoved(EnvDTE::Project* Project);
    void ProjectRenamed(EnvDTE::Project* Project, BSTR OldName);

	//IDebuggerEventHandler methods
	void ContextChanged(EnvDTE::Process* pProcess , EnvDTE::Program* pProgram, EnvDTE::Thread* pThread, EnvDTE::StackFrame* pStackFrame);
	void EnterBreakMode(EnvDTE::dbgEventReason dbgEventReason, EnvDTE::dbgExecutionAction* pdbgExecutionAction);
    void EnterDesignMode(EnvDTE::dbgEventReason dbgEventReason);
    void EnterRunMode(EnvDTE::dbgEventReason dbgEventReason);
    void ExceptionNotHandled(BSTR bstrExceptionType, BSTR bstrName, int nCode, BSTR bstrDescription, EnvDTE::dbgExecutionAction* pdbgExecutionAction);
    void ExceptionThrown(BSTR bstrExceptionType, BSTR bstrName, int nCode, BSTR bstrDescription, EnvDTE::dbgExecutionAction* pdbgExecutionAction);

	//IBuildEventHandler methods
	void OnBuildBegin(EnvDTE::vsBuildScope Scope, EnvDTE::vsBuildAction Action);
	void OnBuildDone(EnvDTE::vsBuildScope Scope, EnvDTE::vsBuildAction Action);
	void OnBuildProjConfigBegin(BSTR Project, BSTR ProjectConfig, BSTR Platform, BSTR SolutionConfig);
	void OnBuildProjConfigDone(BSTR Project, BSTR ProjectConfig, BSTR Platform, BSTR SolutionConfig, VARIANT_BOOL Success);

	//IExchangeControl
	void TestAppNotify(WPARAM wParam, LPARAM lParam);
	void Start(EnvDTE::Project* pCurSelProject, BOOL bDebug);


};
