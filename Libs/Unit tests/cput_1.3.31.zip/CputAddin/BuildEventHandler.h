#pragma once

__interface IBuildEventHandler
{
	void OnBuildBegin(EnvDTE::vsBuildScope Scope, EnvDTE::vsBuildAction Action);
	void OnBuildDone(EnvDTE::vsBuildScope Scope, EnvDTE::vsBuildAction Action);
	void OnBuildProjConfigBegin(BSTR Project, BSTR ProjectConfig, BSTR Platform, BSTR SolutionConfig);
	void OnBuildProjConfigDone(BSTR Project, BSTR ProjectConfig, BSTR Platform, BSTR SolutionConfig, VARIANT_BOOL Success);
};

class BuildEventHandler : public EnvDTE::_dispDebuggerEvents
{
	DWORD m_dwCookie;
	IConnectionPointPtr m_spCP;
	IBuildEventHandler *m_pReceiver;
public:
	BuildEventHandler(void);
	~BuildEventHandler(void);

	BOOL Advise(EnvDTE80::DTE2 *pDTE, IBuildEventHandler *pReceiver);
	void UnAdvise();
	
	//IUnknown
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObject);
    virtual ULONG STDMETHODCALLTYPE AddRef(void);
	virtual ULONG STDMETHODCALLTYPE Release(void);

	//IDispatch
	virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount(UINT *pctinfo);
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfo(UINT iTInfo, LCID lcid, ITypeInfo **ppTInfo);
    virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames(REFIID riid, LPOLESTR *rgszNames, UINT cNames, LCID lcid, DISPID *rgDispId);
    virtual HRESULT STDMETHODCALLTYPE Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS *pDispParams, VARIANT *pVarResult, EXCEPINFO *pExcepInfo, UINT *puArgErr);

};
