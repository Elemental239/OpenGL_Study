#include "StdAfx.h"
#include "AddTracker.h"

CAddTracker::CAddTracker(void)
{
}

CAddTracker::~CAddTracker(void)
{
}

void CAddTracker::AddTestGroup(LPCWSTR lpFile)
{
	if (FALSE == IsInit())
		m_wstrFile = lpFile;
}

void CAddTracker::AddTestFunc(VCCodeModelLibrary::VCCodeFunction* pNewTestFunc)
{
	if (FALSE == IsInit())
		m_spNewTestFunc = pNewTestFunc;
}
