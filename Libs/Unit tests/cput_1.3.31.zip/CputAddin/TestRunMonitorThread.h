#pragma once

class CTestRunMonitorThread
{
ut_private:
	//handle to a monitor thread
	CHandle m_csMonitorThread;
	//window handle that is notified when the monitored process terminates
	HWND m_hWnd;
	//message id that is given by caller to be post to the window defined by m_hWnd
	UINT m_unNotifyMsg;
	//handle of a process that should be monitored
	CHandle m_csProcess;

	wchar_t m_wszProcessFileName[MAX_PATH];
public:
	CTestRunMonitorThread(void);
	~CTestRunMonitorThread(void);

	//starts a new monitor thread
	void Start(HWND hWnd, UINT unNotifyMsg, DWORD dwProcess);
	//stops a current monitor thread if any 
	void Stop();

	inline LPCWSTR GetProcessFileName() const { return m_wszProcessFileName; }
ut_private:
	//monitor thread procedure
	static DWORD WINAPI MonitorProc(LPVOID lpParam);
};
