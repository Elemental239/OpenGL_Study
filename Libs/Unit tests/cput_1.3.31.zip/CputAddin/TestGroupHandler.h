#pragma once
#include "ProjectCodeTypeTree.h"
#include "AddTracker.h"

class CTestGroupHandler
{
ut_private:
	//active project
	const EnvDTE::ProjectPtr m_spOriginProject;
	//test project
	const EnvDTE::ProjectPtr m_spTestProject;
	//contains if defined suitable name for a test group
	CComBSTR m_bstrGroupName;
	//contains if defined a pointer to a code element in a test project that represent the test group class
	EnvDTE::CodeElementPtr m_spTestGroupElement;

	CAtlStringA m_strPrecompileHeader;

	CAddTracker * m_pAddTracker;
public:
	CTestGroupHandler(EnvDTE::Project * pOriginProject, EnvDTE::Project * pTestProject, LPCSTR lpPrecompileHeader, CAddTracker * pAddTracker);
	~CTestGroupHandler(void);

	//creates or finds group test and return TRUE if succeeded and FALSE otherwise
	BOOL MakeTestGroup(LPCWSTR lpTemplate, EnvDTE::CodeElementPtr & spTestGroup);

	BOOL IsThereTestGroup(LPCWSTR lpTemplate, EnvDTE::CodeElementPtr & spTestGroup);

	void CreateAndFillTestGroup(CElementTree<CodeTreeItem> & rNode);

ut_private:
	//checks an original and an test project to define name  for new test group or find one in an test project
	//the result is filled m_bstrGroupName and m_spTestGroupElement if a suitable test group has been already created
	BOOL DefineGroupName(LPCWSTR lpTemplate);

	//Defines if a name is used in global namespace of the given project
	//returns TRUE is so and fills spMatched if it is a class or a structure.
	BOOL IsNameUsedInProject(LPCWSTR lpName, EnvDTE::Project * pProject, EnvDTE::CodeElementPtr & spMatched);

	//creates h and cpp files and add them to the test project
	BOOL CreateTestGroup();

	//defines unique file names for h and cpp file which start with m_bstrGroupName
	BOOL DefineTestGroupFileName(CComBSTR & bstrH, CComBSTR & bstrCpp);

	//creates h file
	BOOL CreateTestGroupHFile(LPCWSTR lpPath);

	//creates cpp file
	BOOL CreateTestGroupCppFile(LPCWSTR lpPath, LPCWSTR lpHFilePath);

	//creates a test group with constructor
	BOOL CreateTestGroupClass(LPCWSTR lpHFilePath, LPCWSTR lpCppFilePath);
};