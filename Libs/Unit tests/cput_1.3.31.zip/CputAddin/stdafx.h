// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef STRICT
#define STRICT
#endif

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef WINVER				// Allow use of features specific to Windows 95 and Windows NT 4 or later.
#define WINVER 0x0500		// Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#endif

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows NT 4 or later.
#define _WIN32_WINNT 0x0500	// Change this to the appropriate value to target Windows 2000 or later.
#endif						

#ifndef _WIN32_WINDOWS		// Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0510 // Change this to the appropriate value to target Windows Me or later.
#endif

#ifndef _WIN32_IE			// Allow use of features specific to IE 4.0 or later.
#define _WIN32_IE 0x0500	// Change this to the appropriate value to target IE 5.0 or later.
#endif

#define _ATL_APARTMENT_THREADED
#define _ATL_NO_AUTOMATIC_NAMESPACE

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit

// turns off ATL's hiding of some common and often safely ignored warning messages
#define _ATL_ALL_WARNINGS


#include "resource.h"
#include <windows.h>
#include <atlbase.h>
#include <atlcom.h>
#include <atlstr.h>
#include <atlcoll.h>
#include <atlfile.h>
#include <atlpath.h>
#include <atlsafe.h>
#include <atlhost.h>
#include <atlctl.h>
#include <atltime.h>
#include <commctrl.h>

using namespace ATL;

#include <msxml2.h>
#include <comdef.h>
#include <comdefsp.h>
#include <Psapi.h>
#include <shellapi.h>

#pragma comment(lib, "Psapi.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "msxml2.lib")
#pragma comment(lib, "comctl32.lib")

#pragma warning( disable : 4278 )
#pragma warning( disable : 4146 )
	//The following #import imports the IDTExtensibility2 interface based on it's LIBID
	#import "libid:AC0714F2-3D04-11D1-AE7D-00A0C90F26F4" version("1.0") lcid("0")  raw_interfaces_only named_guids

	//The following #import imports VS Command Bars based on it's LIBID
	#import "libid:1CBA492E-7263-47BB-87FE-639000619B15" version("8.0") lcid("0") raw_interfaces_only named_guids

	//The following #import imports DTE based on it's LIBID
	#import "libid:80cc9f66-e7d8-4ddd-85b6-d9e6cd0e93e2" version("8.0") lcid("0") raw_interfaces_only named_guids

	//The following #import imports DTE80 based on it's LIBID
	#import "libid:1A31287A-4D7D-413e-8E32-3B374931BD89" version("8.0") lcid("0") raw_interfaces_only named_guids

	//EnvDTE90.dll
	//#import "libid:2CE2370E-D744-4936-A090-3FFFE667B0E1" version("9.0") raw_interfaces_only named_guids

	

	//VCProject.dll - 8.0
	//#import "libid:7DDEAC52-6DC1-46CF-94FC-4C9E3614211D" version("8.0") raw_interfaces_only named_guids
	
	

#if _VS2008
	//VCProject.dll - 9.0
	#import "libid:7B932C1E-942E-4F8F-A71A-015A41FF634B" version("9.0") raw_interfaces_only named_guids

	//vcpkg.dll
	#import "libid:B5D4541F-A1F1-4CE0-B2E7-5DA402367104" version("9.0") raw_interfaces_only named_guids
#else
	//VCProjectEngine.dll
	#import "libid:FBBF3C60-2428-11D7-8BF6-00B0D03DAA06" version("8.0") raw_interfaces_only named_guids

	//vcpkg.dll
	#import "libid:4660A126-0E85-4506-B325-115F0FE27B0D" version("8.0") raw_interfaces_only named_guids
#endif

#pragma warning( default : 4146 )
#pragma warning( default : 4278 )

#ifdef _UT

#include "UtAssert.h"

#else

#define ut_private private
#define ut_protected protected

#endif




#define IfFailGo(x) { hr=(x); if (FAILED(hr)) goto Error; }
#define IfFailGoCheck(x, p) { hr=(x); if (FAILED(hr)) goto Error; if(!p) {hr = E_FAIL; goto Error; } }

class DECLSPEC_UUID("64241C82-7151-45B2-AC4A-8305FE906725") CputLib;

using namespace ATL;

class CAddInModule : public CAtlDllModuleT< CAddInModule >
{
public:
	CAddInModule()
	{
		m_hInstance = NULL;
	}

	DECLARE_LIBID(__uuidof(CputLib))

	inline HINSTANCE GetResourceInstance()
	{
		return m_hInstance;
	}

	inline void SetResourceInstance(HINSTANCE hInstance)
	{
		m_hInstance = hInstance;
	}

private:
	HINSTANCE m_hInstance;
};

extern CAddInModule _AtlModule;

#define TRACEPOINT \
{\
	CStringA str; \
	str.Format("trace point %s %s(%i)\r\n", __FUNCTION__, __FILE__, __LINE__); \
	OutputDebugStringA(str);\
}