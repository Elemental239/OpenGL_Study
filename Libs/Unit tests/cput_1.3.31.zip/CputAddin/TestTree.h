#pragma once
#include "DteFunctions.h"
#include "..\common.h"
#include "..\TransData.h"

struct TestRun
{
	//defines the last run status of the test
	ERunStatus	eStatus;
	//stores user selection for the next run
	BOOL		bChecked;
	//defines if test will be used
	BOOL		bDisabled;
	//defines name
	CAtlStringW wstrName;
	//stores the last test run report 
	CAtlStringW wstrReport;
	//stores the duration of the last test run
	__time64_t	tDuration;

	TestRun() : eStatus(Pending), bChecked(FALSE), bDisabled(FALSE)
	{
	}

	TestRun(const TestRun & rItem)
	{
		eStatus = rItem.eStatus;
		bChecked = rItem.bChecked;
		bDisabled = rItem.bDisabled;
		wstrName = rItem.wstrName;
		wstrReport = rItem.wstrReport;
		tDuration = rItem.tDuration;
	}
};

struct TestGroupRun
{
	//defines the last run status of the test group
	ERunStatus	eStatus;
	//stores user selection
	BOOL		bChecked;
	//defines if test will be used
	BOOL		bDisabled;
	//defines if a test group is expanded
	BOOL		bExpanded;
	//defines name
	CAtlStringW wstrName;
	//stores the last test run report 
	CAtlStringW wstrReport;
	//stores the duration of the last test run
	__time64_t	tDuration;

	CAtlArray<TestRun> aTests;

	TestGroupRun() : eStatus(Pending), bChecked(FALSE), bDisabled(FALSE), bExpanded(TRUE)
	{
	}

	TestGroupRun(const TestGroupRun & rItem)
	{
		eStatus = rItem.eStatus;
		bChecked = rItem.bChecked;
		bDisabled = rItem.bDisabled;
		bExpanded = rItem.bExpanded;
		wstrName = rItem.wstrName;
		wstrReport = rItem.wstrReport;
		tDuration = rItem.tDuration;
		aTests.Copy(rItem.aTests);
	};

	TestGroupRun & operator = (const TestGroupRun & rItem)
	{
		if (this != &rItem)
		{
			eStatus = rItem.eStatus;
			bChecked = rItem.bChecked;
			bDisabled = rItem.bDisabled;
			bExpanded = rItem.bExpanded;
			wstrName = rItem.wstrName;
			wstrReport = rItem.wstrReport;
			tDuration = rItem.tDuration;
			aTests.Copy(rItem.aTests);
		}
		return *this;
	}
};

//used to gather tests from a test project,
class TestProject : public IRecursiveEnumEvent
{
ut_private:
	CAtlArray<TestGroupRun> m_aGroups;

	virtual BOOL Element(EnvDTE::CodeElement * pElement);
	void ParseGetTestsFunc(LPCWSTR lpBody);
public:
	TestProject(void);
	~TestProject(void);

	BOOL Prepare(const EnvDTE::ProjectPtr & spProject);
	const CAtlArray<TestGroupRun> & GetTestGroups() const { return m_aGroups; }
};
