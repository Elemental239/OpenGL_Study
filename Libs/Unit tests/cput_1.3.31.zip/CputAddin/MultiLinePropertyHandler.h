#pragma once

class CMultiLinePropertyHandler
{
ut_private:
	CAtlArray<CAtlStringW> m_aItems; //currently there are not many items so there is no need to use a map
	BOOL m_bIsModified;
public:
	CMultiLinePropertyHandler(void);
	CMultiLinePropertyHandler(LPCWSTR lpPropertyLine);
	~CMultiLinePropertyHandler(void);

	//defines if a Property Line has been modified
	inline BOOL IsModified() const { return m_bIsModified; }

	//parses line to individual Definitions and stores them in m_aItems
	void Parse(const CAtlStringW & strPropertyLine, wchar_t chDelimiter = L';');
	void Parse(const CAtlStringW & strPropertyLine, LPCWSTR lpDelimiter);

	//returns TRUE if lpProperty is defined in a parsed Property Line
	BOOL IsDefined(LPCWSTR lpProperty) const;

	//removes Property if it was in a parsed Property Line
	void RemoveIfExist(LPCWSTR lpProperty);

	//add Property if it is not exist
	void Add(LPCWSTR lpProperty);

	//reassembles Property intoProperty Line
	void GetPropertyLine(CAtlStringW & str, wchar_t chDelimiter = L';') const;
	void GetPropertyLine(CAtlStringW & str, LPCWSTR lpDelimiter) const;

	//gets items count
	inline size_t GetCount() const { return m_aItems.GetCount(); }

	//returns entry
	inline CAtlStringW GetAt(size_t nIndex) const { return m_aItems.GetAt(nIndex); }

	void SetAt(size_t nIndex, const CAtlStringW & wstrValue);

};
