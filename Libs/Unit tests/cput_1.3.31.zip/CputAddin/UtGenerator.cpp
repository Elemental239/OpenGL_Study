#include "stdafx.h"
#include "UtGenerator.h"
#include "ProjectGenerator.h"
#include "TestGroupHandler.h"
#include "TestFunctionHandler.h"
#include "NewTestDlg.h"
#include "SourceCodeHandler.h"

BOOL CUtGenerator::GenerateTests(EnvDTE80::DTE2 * pDTE)
{
	BOOL bRet = FALSE;
	EnvDTE::DocumentPtr spDocument;
	EnvDTE::ProjectItemPtr spProjItem;
	EnvDTE::CodeModelPtr spCodeModel;
	EnvDTE::CodeElementsPtr spCodeElements;
	IDispatchPtr spDispatch;
	CProjectCodeTypeTree tree;
	EnvDTE::WindowPtr spMainWnd;
	HWND hwndMainWnd;
	CComBSTR bstrLanguage;

	if (SUCCEEDED(pDTE->get_MainWindow(&spMainWnd)) && (spMainWnd) &&
		SUCCEEDED(spMainWnd->get_HWnd((long*)&hwndMainWnd)))
	{
		CNewTestDlg dlg(pDTE, m_wstrSuffix);
		if (IDOK == dlg.DoModal(hwndMainWnd))
		{
			m_spOriginProject = dlg.GetOriginalProject();

			if (dlg.IsNewTestProject())
			{
				if (FALSE == GenerateUTProject(pDTE, dlg.GetTestProjectName()))
					return FALSE;
			}
			else
			{
				m_spTestProject = dlg.GetTestProject();
				GetPrecompileHeader(m_strPrecompileHeader);
			}

			CAddTracker csAddTracker;

			CreateUnitTestsRoot(dlg.GetTree(), &csAddTracker);
			bRet = TRUE;

			if (csAddTracker.m_spNewTestFunc)
			{
				CComBSTR bstrFile;
				EnvDTE::ItemOperationsPtr spItemOperations;
				EnvDTE::WindowPtr spWindow;
				EnvDTE::TextPanePtr spTextPane;
				EnvDTE::TextPointPtr spTextPoint;
				EnvDTE::TextWindowPtr spTextWindow;

				if (SUCCEEDED(csAddTracker.m_spNewTestFunc->get_File(&bstrFile)) &&
					SUCCEEDED(pDTE->get_ItemOperations(&spItemOperations)) &&
					SUCCEEDED(spItemOperations->OpenFile(bstrFile, CComBSTR(EnvDTE::vsViewKindCode), &spWindow)) &&
					SUCCEEDED(spWindow->get_Object(&spDispatch)) &&
					(spTextWindow = spDispatch) &&
					SUCCEEDED(spTextWindow->get_ActivePane(&spTextPane)) &&
					SUCCEEDED(csAddTracker.m_spNewTestFunc->get_StartPoint(&spTextPoint))
					)
				{
					VARIANT_BOOL vb;
					spTextPane->TryToShow(spTextPoint, EnvDTE::vsPaneShowTop, CComVariant(), &vb);
				}
			}
			else if (csAddTracker.m_wstrFile.GetLength() )
			{
				EnvDTE::ItemOperationsPtr spItemOperations;
				EnvDTE::WindowPtr spWindow;

				if (SUCCEEDED(pDTE->get_ItemOperations(&spItemOperations)) &&
					SUCCEEDED(spItemOperations->OpenFile(CComBSTR(csAddTracker.m_wstrFile), CComBSTR(EnvDTE::vsViewKindCode), &spWindow))
					)
				{
					spWindow->Activate();
				}

			}
		}
	}
	return bRet;
}

BOOL CUtGenerator::FindMainFunction(EnvDTE::CodeModel * pCodeModel, BOOL bIsAnsi, EnvDTE::CodeFunctionPtr & spMainFunction)
{
	BOOL bRet = FALSE;
	
	CComBSTR bstrName(bIsAnsi ? L"main" : L"wmain");
	EnvDTE::CodeModelPtr spCodeModel;
	VCCodeModelLibrary::VCCodeModelPtr spVCCodeModel;
	EnvDTE::CodeElementsPtr spCodeElements;
	VCCodeModelLibrary::VCCodeElementsPtr spVCCodeElements;
	IDispatchPtr spDispatch;

	if ((spVCCodeModel = pCodeModel) &&
		SUCCEEDED(spVCCodeModel->get_Functions(&spCodeElements)) &&
		(spVCCodeElements = spCodeElements) &&
		SUCCEEDED(spVCCodeElements->Find(bstrName, &spDispatch)) &&
		(spMainFunction = spDispatch))
	{
		bRet = TRUE;
	}
	return bRet;
}

BOOL CUtGenerator::FindPrecompileHeaderInclude(EnvDTE::CodeElements * pCodeElements, EnvDTE::CodeFunction * pMainFunction, CComBSTR bstrPrecompileHeader, EnvDTE::CodeElementPtr & spPrecompileHeaderInclude)
{
	BOOL bRet = FALSE;
	EnvDTE::ProjectItemPtr spProjectItem;
	CComBSTR bstrFileName;
	long lCount = 0;

	if ((pMainFunction) && (pCodeElements) &&
		SUCCEEDED(pMainFunction->get_ProjectItem(&spProjectItem)) &&
		SUCCEEDED(spProjectItem->get_Name(&bstrFileName)) &&
		SUCCEEDED(pCodeElements->get_Count(&lCount)))
	{
		//enumerate top level elements to find the include precompile header statement in 
		//the file whehe main (wmain) is defined
		EnvDTE::CodeElementPtr spCodeElement;
		EnvDTE::vsCMElement eKind;
		CComBSTR bstrName;
		CComBSTR bstrProjectItemName;
			
		for (CComVariant var(1L); var.lVal <= lCount; ++var.lVal)
		{
			
			if (SUCCEEDED(pCodeElements->Item(var, &spCodeElement)) &&
				SUCCEEDED(spCodeElement->get_Kind(&eKind)) &&
				(EnvDTE::vsCMElementIncludeStmt == eKind) &&
				SUCCEEDED(spCodeElement->get_Name(&bstrName)) &&
				(0 == _wcsicmp(bstrName, bstrPrecompileHeader)) &&
				SUCCEEDED(spCodeElement->get_ProjectItem(&spProjectItem)) &&
				SUCCEEDED(spProjectItem->get_Name(&bstrProjectItemName)) &&
				(0 == _wcsicmp(bstrFileName, bstrProjectItemName)))
			{
				//the element was found
				bRet = TRUE; 
				spPrecompileHeaderInclude = spCodeElement;
				break;
			}
		} //for (CComVariant var(0L);
	}
	return bRet;
}

BOOL CUtGenerator::GenerateUTProject(EnvDTE80::DTE2 * pDTE, LPCWSTR lpNewProjName)
{
	BOOL bRet = FALSE;
	EnvDTE::_SolutionPtr spSolution;
	CComBSTR bstrFileName;
	CProjectGenerator csProjectGenerator;

	if (SUCCEEDED(m_spOriginProject->get_FileName(&bstrFileName)) &&
		csProjectGenerator.MakeTestProject(bstrFileName, lpNewProjName) &&
		SUCCEEDED(pDTE->get_Solution(&spSolution)) && (spSolution) &&
		SUCCEEDED(spSolution->AddFromFile(CComBSTR(csProjectGenerator.GetTestProjectPath()), VARIANT_FALSE, &m_spTestProject)))
	{
		GetPrecompileHeader(m_strPrecompileHeader);

		AddUtAccessModifiers();

		if (csProjectGenerator.IsModifyMainNeeded())
		{
			//
			EnvDTE::CodeModelPtr spCodeModel;
			CComBSTR bstr;
			EnvDTE::TextPointPtr spStartTextPoint;
			EnvDTE::TextPointPtr spEndTextPoint;
			EnvDTE::EditPointPtr spEditPoint;
			EnvDTE::CodeFunctionPtr spMainFunction;
			
			if (SUCCEEDED(m_spOriginProject->get_CodeModel(&spCodeModel)) && (spCodeModel) &&
				FindMainFunction(spCodeModel, csProjectGenerator.IsAnsi(), spMainFunction) &&
				SUCCEEDED(spMainFunction->get_StartPoint(&spStartTextPoint)) &&
				SUCCEEDED(spMainFunction->get_EndPoint(&spEndTextPoint)) &&
				SUCCEEDED(spStartTextPoint->CreateEditPoint(&spEditPoint)) &&
				SUCCEEDED(spEditPoint->GetText(CComVariant((LPDISPATCH)spEndTextPoint), &bstr)))
			{
				CAtlStringW wstr = bstr;
				ReplaceCommentAndTextLiteral(wstr, wstr);
				if (-1 != wstr.Find(L"LaunchUtSequence();"))
				{
					bRet = TRUE; //no modification is needed
				} else
				{
					wstr.Remove(L'\r'); //'\r' or '\n' is not used in the internal model
					int nFound = wstr.Find(L'{');
					if ((-1 != nFound) && 
						SUCCEEDED(spEditPoint->CharRight(nFound + 1)) &&
						SUCCEEDED(spEditPoint->Insert(CComBSTR(L"\r\n#ifdef _UT\r\n\tLaunchUtSequence();\r\n\treturn 0;\r\n#endif\r\n"))))
					{
						if (m_strPrecompileHeader.IsEmpty())
						{
							if (SUCCEEDED(spEditPoint->StartOfDocument()) &&
								SUCCEEDED(spEditPoint->Insert(CComBSTR(L"\r\n#ifdef _UT\r\n#include <UtAssert.h>\r\n#endif\r\n"))))
							{
								bRet = TRUE;
							}
						} else {
							//if precompile header is used all include statements should be after it
							EnvDTE::CodeElementPtr spPrecompileHeaderInclude;
							EnvDTE::TextPointPtr spPrecompileIncludeEndTextPoint;
							EnvDTE::EditPointPtr spIncludeEditPoint;
							EnvDTE::CodeElementsPtr spCodeElements;
							
							if (SUCCEEDED(spCodeModel->get_CodeElements(&spCodeElements)) && (spCodeElements) &&
								FindPrecompileHeaderInclude(spCodeElements, spMainFunction, CComBSTR(m_strPrecompileHeader), spPrecompileHeaderInclude) &&
								SUCCEEDED(spPrecompileHeaderInclude->get_EndPoint(&spPrecompileIncludeEndTextPoint)) &&
								SUCCEEDED(spPrecompileIncludeEndTextPoint->CreateEditPoint(&spIncludeEditPoint)) &&
								SUCCEEDED(spIncludeEditPoint->Insert(CComBSTR(L"\r\n#ifdef _UT\r\n#include <UtAssert.h>\r\n#endif\r\n"))))
							{
								bRet = TRUE;
							}
						}
					}
				}
			}
			else
			{
				//For console application sometimes a main function could not be fully retrieved
				//spMainFunction->get_StartPoint(&spStartTextPoint)  returns E_INVALIDARG
				//so an unit test project creation has to be undone
				spSolution->Remove(m_spTestProject);
				DeleteFile(csProjectGenerator.GetTestProjectPath());

				CAtlStringW wstrCaption, wstrMessage;
				wstrCaption.LoadString(_AtlModule.GetResourceInstance(), IDS_WARNING);
				wstrMessage.LoadString(_AtlModule.GetResourceInstance(), IDS_UNABLETORETRIEVEMAINBODY);

				MessageBoxW(NULL, wstrMessage.GetString(), wstrCaption.GetString(), MB_ICONWARNING);
			}
		} else {
			//add new _tmain
			CAtlString str;
			EnvDTE::ProjectItemsPtr spProjectItems;
			EnvDTE::ProjectItemPtr spProjectItem;

			if (SUCCEEDED(m_spTestProject->get_ProjectItems(&spProjectItems)) &&
				GenerateMainTestCpp(csProjectGenerator.GetTestProjectPath(), m_strPrecompileHeader, str) &&
				SUCCEEDED(spProjectItems->AddFromFile(CComBSTR(str), &spProjectItem)))
			{
				bRet = TRUE;
			}
		}
	}

	if (bRet)
	{
		CComBSTR bstr;
		IDispatchPtr spDispat�h;
		VCProjectEngineLibrary::VCProjectPtr spVCProject;
		if (SUCCEEDED(m_spTestProject->get_Object(&spDispat�h)) &&
			(spVCProject = spDispat�h) &&
			SUCCEEDED(m_spOriginProject->get_UniqueName(&bstr)))
		{
			spVCProject->put_keyword(bstr);
		}
	}
	return bRet;
}

/*
void CUtGenerator::CreateUnitTests(CElementTree<CodeTreeItem> & rNode, CAddTracker* pAddTracker)
{
	ATLASSERT((m_spOriginProject) && (m_spTestProject));
	if ((m_spOriginProject == NULL) || (m_spTestProject == NULL))
		return;

	POSITION pos =  rNode.GetHeadPosition();
	while(pos)
	{
		CElementTree<CodeTreeItem> & rSubNode = rNode.GetNext(pos);
		const CodeTreeItem & rValue = rSubNode.GetValue();

		if (rValue.Checked)
		{
			CAtlStringW wstrGroupTemplate;
			CAtlStringW wstrFunctionTemplate;
			const CodeTreeItem & rParent = rNode.GetValue();
			if (rValue.eKind == EnvDTE::vsCMElementFunction)
			{
				wstrGroupTemplate = rParent.Name.IsEmpty() ? m_wstrGlobal : rParent.Name;
		
				if (rValue.ElementData.eFunctionKind & EnvDTE::vsCMFunctionConstructor)
					wstrFunctionTemplate = L"Constructor";
				else if (rValue.ElementData.eFunctionKind & EnvDTE::vsCMFunctionDestructor)
					wstrFunctionTemplate = L"Destructor";
				else if (rValue.ElementData.eFunctionKind & EnvDTE::vsCMFunctionOperator)
					wstrFunctionTemplate = L"Operator";
				else
					wstrFunctionTemplate = rValue.Name;
			} 
			else 
			{
				wstrGroupTemplate = rValue.Name;
			}

			wstrGroupTemplate.Append(m_wstrSuffix);
			wstrFunctionTemplate.Append(m_wstrSuffix);

			EnvDTE::CodeElementPtr spTestGroupElement;
			CTestGroupHandler csTestGroupHandler(m_spOriginProject, m_spTestProject, m_strPrecompileHeader, pAddTracker);
			if (csTestGroupHandler.MakeTestGroup(wstrGroupTemplate, spTestGroupElement))
			{
				CTestFunctionHandler csTestFunctionHandler(spTestGroupElement, pAddTracker);
				csTestFunctionHandler.Add(wstrFunctionTemplate);
			}
		}

		if (rSubNode.ChildrenCount())
			CreateUnitTests(rSubNode, pAddTracker);
	}
}
*/

void CUtGenerator::CreateUnitTestsRoot(CElementTree<CodeTreeItem> & rNode, CAddTracker* pAddTracker)
{
	ATLASSERT((m_spOriginProject) && (m_spTestProject));
	if ((m_spOriginProject == NULL) || (m_spTestProject == NULL))
		return;

	EnumUnitTestTree(rNode, pAddTracker);
}

void CUtGenerator::EnumUnitTestTree(CElementTree<CodeTreeItem> & rNode, CAddTracker* pAddTracker)
{
	BOOL bIsAnyFunction = rNode.GetValue().Checked;

	if (FALSE == bIsAnyFunction)
	{
		POSITION pos =  rNode.GetHeadPosition();
		while(pos)
		{
			const CodeTreeItem & rValue = rNode.GetNext(pos).GetValue();
			if ((rValue.Checked) && (rValue.eKind == EnvDTE::vsCMElementFunction))
			{
				bIsAnyFunction = TRUE;
				break;
			}
		}
	}

	if (bIsAnyFunction)
	{
		EnvDTE::CodeElementPtr spTestGroupElement;
		CAtlStringW wstrGroupName = rNode.GetValue().Name;
	
		CElementTree<CodeTreeItem>* pParent = rNode.GetParent();
		while(pParent)
		{
			wstrGroupName.Insert(0, pParent->GetValue().Name);
			pParent = pParent->GetParent();
		}
		
		if (wstrGroupName.IsEmpty())
			wstrGroupName = m_wstrGlobal;
		wstrGroupName.Append(L"Test");

		CTestGroupHandler csTestGroupHandler(m_spOriginProject, m_spTestProject, m_strPrecompileHeader, pAddTracker);
		if (csTestGroupHandler.IsThereTestGroup(wstrGroupName, spTestGroupElement))
		{
			CTestFunctionHandler csTestFunctionHandler(spTestGroupElement, pAddTracker);
			csTestFunctionHandler.Add(rNode);
		} 
		else
		{
			csTestGroupHandler.CreateAndFillTestGroup(rNode);
		}
	}

	POSITION pos =  rNode.GetHeadPosition();
	while(pos)
	{
		CElementTree<CodeTreeItem> & rNext = rNode.GetNext(pos);
		if (rNext.GetValue().eKind != EnvDTE::vsCMElementFunction)
		{
			EnumUnitTestTree(rNext, pAddTracker);
		}
	}
}

void CUtGenerator::GetPrecompileHeader(CAtlStringA & strPrecompileHeader)
{
	HRESULT hr = E_FAIL;
	VCProjectEngineLibrary::VCProjectPtr spVCProject;
	CComVariant vtVCCLCompilerTool(L"VCCLCompilerTool");
	VCProjectEngineLibrary::IVCCollectionPtr spVCConfigurations, spTools;
	VCProjectEngineLibrary::VCConfigurationPtr spVCConfiguration;
	VCProjectEngineLibrary::VCCLCompilerToolPtr spVCCLCompilerTool;
	IDispatchPtr spDispatch;
	CComBSTR bstr;
	VCProjectEngineLibrary::pchOption eUsePrecompiledHeader = VCProjectEngineLibrary::pchNone;

	if (SUCCEEDED(hr = m_spTestProject->get_Object(&spDispatch)) &&
		(spVCProject = spDispatch) &&
		SUCCEEDED(spVCProject->get_Configurations(&spDispatch)) &&
		(spVCConfigurations = spDispatch) &&
		SUCCEEDED(hr = spVCConfigurations->Item(CComVariant(1), &spDispatch)) && //use first configuration
		(spVCConfiguration = spDispatch) &&
		SUCCEEDED(hr = spVCConfiguration->get_Tools(&spDispatch)) &&
		(spTools = spDispatch) &&
		SUCCEEDED(hr = spTools->Item(vtVCCLCompilerTool, &spDispatch)) &&
		(spVCCLCompilerTool = spDispatch) &&
		SUCCEEDED(hr = spVCCLCompilerTool->get_UsePrecompiledHeader(&eUsePrecompiledHeader)) &&
		(eUsePrecompiledHeader != VCProjectEngineLibrary::pchNone) &&
		SUCCEEDED(hr = spVCCLCompilerTool->get_PrecompiledHeaderThrough(&bstr)))
	{
		strPrecompileHeader = bstr;
	}
}


BOOL CUtGenerator::GenerateMainTestCpp(const CAtlString & strTestProjectPath, const CAtlStringA & strPrecompileHeader, CAtlString & strMainTestCppFilePath)
{
	CPath path = strTestProjectPath;
	path.RemoveExtension();
	path.AddExtension(_T(".cpp"));

	CAtlStringA strContent;
	if (strPrecompileHeader.GetLength())
	{
		strContent.Append("#include \"");
		strContent.Append(strPrecompileHeader);
		strContent.Append("\"\r\n");
	}
	strContent.Append("#include <tchar.h>\r\n#include <UtAssert.h>\r\n\r\nint _tmain(int argc, _TCHAR* argv[])\r\n{\r\n\tLaunchUtSequence();\r\n\treturn 0;\t\r\n}\r\n");
	
	CAtlFile fileMainTestCpp;
	strMainTestCppFilePath = path.m_strPath;
	fileMainTestCpp.Create(strMainTestCppFilePath, GENERIC_WRITE, 0, CREATE_NEW);

	return SUCCEEDED(fileMainTestCpp.Write(strContent.GetString(), strContent.GetLength()));
}

BOOL CUtGenerator::FindFile(EnvDTE::ProjectItems * pProjectItems, const CComBSTR & bstrFileName, EnvDTE::ProjectItemPtr & spProjectItem)
{
	long nItemsCount = 0;
	pProjectItems->get_Count(&nItemsCount);
	
	CComBSTR bstrName;
	for (CComVariant vt(1); vt.lVal < nItemsCount; ++vt.lVal)
	{
		EnvDTE::ProjectItemPtr spItem;
		EnvDTE::ProjectItemsPtr spSubItems;
		long nSubCount = 0;

		if (SUCCEEDED(pProjectItems->Item(vt, &spItem)) &&
			SUCCEEDED(spItem->get_ProjectItems(&spSubItems)) &&
			SUCCEEDED(spSubItems->get_Count(&nSubCount))) //define is the item is folder or file
		{
			if (nSubCount)
			{
				if (FindFile(spSubItems, bstrFileName, spProjectItem))
					return TRUE;
			}
			else
			{
				if (SUCCEEDED(spItem->get_Name(&bstrName)) &&
					(0 == _wcsicmp(bstrName, bstrFileName)))
				{
					spProjectItem = spItem;
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

BOOL CUtGenerator::AddUtAccessModifiers()
{
	BOOL bRet = FALSE;
	if ((m_spOriginProject) && (m_strPrecompileHeader.GetLength()))
	{
		EnvDTE::ProjectItemsPtr spProjectItems;
		EnvDTE::ProjectItemPtr spProjectItem;
		EnvDTE::FileCodeModelPtr spFileCodeModel;
		VCCodeModelLibrary::VCFileCodeModelPtr spVCFileCodeModel;
		EnvDTE::TextPointPtr spStartTextPoint, spEndTextPoint;
		EnvDTE::EditPointPtr spEditPoint;
		CComBSTR bstr;
		
		if (SUCCEEDED(m_spOriginProject->get_ProjectItems(&spProjectItems)) &&
			FindFile(spProjectItems, m_strPrecompileHeader.GetString(), spProjectItem) &&
			SUCCEEDED(spProjectItem->get_FileCodeModel(&spFileCodeModel)) &&
			(spVCFileCodeModel = spFileCodeModel) &&
			SUCCEEDED(spVCFileCodeModel->get_StartPoint(&spStartTextPoint)) &&
			SUCCEEDED(spVCFileCodeModel->get_EndPoint(&spEndTextPoint)) &&
			SUCCEEDED(spStartTextPoint->CreateEditPoint(&spEditPoint)) &&
			SUCCEEDED(spEditPoint->GetText(CComVariant((LPDISPATCH)spEndTextPoint), &bstr)))
		{
			CStringW wstr(bstr);
			ReplaceCommentAndTextLiteral(wstr, wstr);


			if (-1 == wstr.Find(L"#define ut_private private"))
			{
				CComBSTR bstrUtDefines(L"\
#ifdef _UT\r\n\
#define ut_private public\r\n\
#define ut_protected public\r\n\
#else\r\n\
#define ut_private private\r\n\
#define ut_protected protected\r\n\
#endif\r\n\r\n");
				if (SUCCEEDED(spEndTextPoint->CreateEditPoint(&spEditPoint)))
					spEditPoint->Insert(bstrUtDefines);
			}
			bRet = TRUE;
		}
	}

	return bRet;
}