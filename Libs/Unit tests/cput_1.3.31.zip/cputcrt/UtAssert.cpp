#include "StdAfx.h"
#include "UtAssert.h"

CUtException::CUtException(LPCSTR lpFile, long nLine, LPCSTR lpFunction) :
m_lpFile(lpFile), m_nLine(nLine), m_lpFunction(lpFunction), m_lpMessage(NULL),
m_eActionCode(acContinue), m_eReportStatus(rsError)
{
	
}

CUtException::CUtException(LPCSTR lpFile, long nLine, LPCSTR lpFunction, LPCSTR lpMessage) :
m_lpFile(lpFile), m_nLine(nLine), m_lpFunction(lpFunction), m_lpMessage(NULL),
m_eActionCode(acContinue), m_eReportStatus(rsError)
{
	if (lpMessage)
	{
		size_t ret = 0;
		size_t len = strlen(lpMessage) + 1;
		m_lpMessage = new wchar_t[len];
		mbstowcs_s(&ret, m_lpMessage, len, lpMessage, len);
	}
}

CUtException::CUtException(LPCSTR lpFile, long nLine, LPCSTR lpFunction, LPCWSTR lpMessage) :
m_lpFile(lpFile), m_nLine(nLine), m_lpFunction(lpFunction), m_lpMessage(NULL),
m_eActionCode(acContinue), m_eReportStatus(rsError)
{
	if (lpMessage)
	{
		size_t len = wcslen(lpMessage) + 1;
		m_lpMessage = new wchar_t[len];
		wcscpy_s(m_lpMessage, len, lpMessage);
	}
}

CUtException::CUtException(LPCSTR lpFile, long nLine, LPCSTR lpFunction, EActionCode eActionCode, EReportStatus eReportStatus) :
m_lpFile(lpFile), m_nLine(nLine), m_lpFunction(lpFunction), m_lpMessage(NULL),
m_eActionCode(eActionCode), m_eReportStatus(eReportStatus)
{
	
}

CUtException::CUtException(LPCSTR lpFile, long nLine, LPCSTR lpFunction, EActionCode eActionCode, EReportStatus eReportStatus, LPCSTR lpMessage) :
m_lpFile(lpFile), m_nLine(nLine), m_lpFunction(lpFunction), m_lpMessage(NULL),
m_eActionCode(eActionCode), m_eReportStatus(eReportStatus)
{
	if (lpMessage)
	{
		size_t ret = 0;
		size_t len = strlen(lpMessage) + 1;
		m_lpMessage = new wchar_t[len];
		mbstowcs_s(&ret, m_lpMessage, len, lpMessage, len);
	}
}

CUtException::CUtException(LPCSTR lpFile, long nLine, LPCSTR lpFunction, EActionCode eActionCode, EReportStatus eReportStatus, LPCWSTR lpMessage) :
m_lpFile(lpFile), m_nLine(nLine), m_lpFunction(lpFunction), m_lpMessage(NULL),
m_eActionCode(eActionCode), m_eReportStatus(eReportStatus)
{
	if (lpMessage)
	{
		size_t len = wcslen(lpMessage) + 1;
		m_lpMessage = new wchar_t[len];
		wcscpy_s(m_lpMessage, len, lpMessage);
	}
}


CUtException::CUtException(const CUtException & r) :
m_lpFile(r.m_lpFile), m_nLine(r.m_nLine), m_lpFunction(r.m_lpFunction), m_lpMessage(NULL),
m_eActionCode(r.m_eActionCode), m_eReportStatus(r.m_eReportStatus)
{
	if (r.m_lpMessage)
	{
		size_t len = wcslen(r.m_lpMessage) + 1;
		m_lpMessage = new wchar_t[len];
		wcscpy_s(m_lpMessage, len, r.m_lpMessage);
	}
}

CUtException::~CUtException()
{
	delete[] m_lpMessage;
}