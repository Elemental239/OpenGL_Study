// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers

#include <tchar.h>
#include <windows.h>
#include <atlbase.h>
#include <atlcom.h>
#include <atlstr.h>
#include <atlcoll.h>
#include <atlfile.h>
#include <atlpath.h>
#include <atltime.h>
#include <atlsafe.h>

#include <msxml2.h>
#include <comdef.h>
#include <comdefsp.h>
#include <shellapi.h>

#pragma comment(lib, "msxml2.lib")
#pragma comment(lib, "Shell32.lib")

#include "utassert.h"

#include "UtProjCommandLineParser.h"

extern CUtProjCommandLineParser g_csUtProjCommandLineParser;
