#include "StdAfx.h"
#include "UtProjCommandLineParser.h"

CUtProjCommandLineParser::CUtProjCommandLineParser(void) :
	m_nInputPathIndex(-1)
{
	m_aArgs = CommandLineToArgvW(GetCommandLineW(), &m_nArgc);

	Initialize();
}

CUtProjCommandLineParser::~CUtProjCommandLineParser(void)
{
}

void CUtProjCommandLineParser::Initialize()
{
	DefineInputPath();
	DefineOutputPath();
}

void CUtProjCommandLineParser::DefineInputPath()
{
	//currently only first argument can be an input unit test set
	m_nInputPathIndex = ((GetCount() > 1) && (*(GetAt(1)) != L'/')) ? 1 : -1;
}

void CUtProjCommandLineParser::DefineOutputPath()
{
	int nIndex = GetIndex(L"/o");
	if ((nIndex > 0) && (GetCount() > nIndex + 1))
	{
		wcscpy_s(m_szOutputPath, _countof(m_szOutputPath), GetAt(nIndex + 1));
	}
	else
	{
		//use default
		GetModuleFileNameW(NULL, m_szOutputPath, _countof(m_szOutputPath));
		wcscat_s(m_szOutputPath, _countof(m_szOutputPath), L"_UT_report.xml");
	}
}

void CUtProjCommandLineParser::DefineDumpPath()
{
	int nIndex = GetIndex(L"/d");
	if ((nIndex > 0) && (GetCount() > nIndex + 1))
	{
		wcscpy_s(m_szDumpPath, _countof(m_szDumpPath), GetAt(nIndex + 1));
	}
	else
	{
		//use default
		GetModuleFileNameW(NULL, m_szDumpPath, _countof(m_szDumpPath));
		wcscat_s(m_szDumpPath, _countof(m_szDumpPath), L".dmp");
	}
}

LPCWSTR CUtProjCommandLineParser::GetInputTestSetPath() const
{
	if (m_nInputPathIndex != -1)
		return GetAt(m_nInputPathIndex);
	
	return NULL;
}

int CUtProjCommandLineParser::GetIndex(LPCWSTR lpArg) const
{
	for (int n = 0; n < GetCount(); ++n)
		if (wcscmp(m_aArgs[n], lpArg) == 0)
			return n;

	return -1;
}

int CUtProjCommandLineParser::GetIndexI(LPCWSTR lpArg) const
{
	for (int n = 0; n < GetCount(); ++n)
		if (_wcsicmp(m_aArgs[n], lpArg) == 0)
			return n;

	return -1;
}
