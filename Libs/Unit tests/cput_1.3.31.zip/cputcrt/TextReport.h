#pragma once
#include "IReportNotification.h"

/**********************************************************************************
Console text format:

Unit Test Run
Command Line : <command line>
Started : <start time>
Filter : none| file | interactive

The <test group name> test group has started
        The <unit test name> test finished, status <status>, time <test duration> second(s)
	 [report <unit test execution report>]
		�
The <test group name>  test group has finished, status <status>, time <group execution time> second(s)
[report <unit test execution report>]

�

Ended : <end time>
**********************************************************************************/


class CTextReport : public IReportNotification
{
public:
	CTextReport(void);
	~CTextReport(void);

	//IReportNotification
	void Start(EFilter eFilter);
	void GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam);
	void TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam);
	void TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam);
	void GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam);
	void End();
};
