#pragma once
#include "IReportNotification.h"

class CReportBuilder : public IReportNotification
{
ut_private:
	CAtlArray<IReportNotification*>	m_aSubscribers;
public:
	CReportBuilder(void);
	~CReportBuilder(void);

	void Subscribe(IReportNotification * p);
	void Unsubscribe(IReportNotification * p);

	//IReportNotification
	void Start(EFilter eFilter);
	void GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam);
	void TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam);
	void TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam);
	void GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam);
	void End();
};
