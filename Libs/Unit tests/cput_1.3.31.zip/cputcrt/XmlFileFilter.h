#pragma once
#include "..\TransData.h"

/**********************************************************************************
The unit test set file has following format:

<testrun>
	<group name="group name">
		<ut name="unit test name"/>
		<ut name="..."/>
		...
	</group>
	<group name="...">
	</group>
	...
</testrun>

sequence of groups and unit tests define execution order
**********************************************************************************/

class CXmlFileFilter
{
ut_private:
	IXMLDOMDocumentPtr m_spDocument;
public:
	CXmlFileFilter(void);
	~CXmlFileFilter(void);

	inline BOOL IsLoaded() const { return m_spDocument != NULL; }

	BOOL DefineTestsToRun(TestPackTransData & rTestPackTransData);
ut_private:
	//reset all tests and groups
	void Reset(TestPackTransData & rTestPackTransData);

	void ProcessGroup(const long nGroup, const IXMLDOMElementPtr & spGroup, TestPackTransData & rTestPackTransData);
};
