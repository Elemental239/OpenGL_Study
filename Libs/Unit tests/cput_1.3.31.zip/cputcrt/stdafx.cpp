// stdafx.cpp : source file that includes just the standard includes
// cputcrt.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

//this is global read-only options 
//IMPORTANT! Should not be used in other static and global object before main function
CUtProjCommandLineParser g_csUtProjCommandLineParser;