#pragma once

/**********************************************************************************
A unit test binary can have following command line
<app path>[<test set>][/o <output file>][/d <dump file>]
<app path> - executing application path,
<test set> - xml file with unit test set put that would be executed in given order,
/o � defines output file name(by default <app path>"_UT_report.xml"),
<output file> - path or file name for output xml report,
/d - defines dump file name (by default <app path> ".dmp"),
<dump file> - path or file name for crash mini dump.
**********************************************************************************/


class CUtProjCommandLineParser
{
ut_private:
	wchar_t m_szOutputPath[MAX_PATH];
	wchar_t m_szDumpPath[MAX_PATH];

	LPWSTR*	m_aArgs;
	int		m_nArgc;

	void Initialize();

	void DefineInputPath();
	void DefineOutputPath();
	void DefineDumpPath();

	int m_nInputPathIndex;

	//defines if an argument is presented in command line
	//returns -1 if not and an argument index in sequence
	int GetIndex(LPCWSTR lpArg) const;

	//defines if an argument is presented in command line regardless of case
	//returns -1 if not and an argument index in sequence
	int GetIndexI(LPCWSTR lpArg) const;

	//returns number of arguments in the parsed command line
	inline int GetCount() const { return m_nArgc; }

	//retruns an argument if such index exists of NULL otherwise
	inline LPCWSTR GetAt(int nIndex) const { return (nIndex >= 0) || (nIndex < m_nArgc) ? m_aArgs[nIndex] : NULL; }


public:
	CUtProjCommandLineParser(void);
	~CUtProjCommandLineParser(void);

	inline BOOL IsInputTestSetDefined() const { return m_nInputPathIndex != -1; }
	LPCWSTR GetInputTestSetPath() const;
	inline LPCWSTR GetOutputPath() const { return m_szOutputPath; };
	inline LPCWSTR GetDumpPath() const { return m_szDumpPath; };


};
