#include "stdafx.h"
#include "XmlReport.h"

const CComBSTR CXmlReport::s_bstrGroup(L"group");
const CComBSTR CXmlReport::s_bstrName(L"name");
const CComBSTR CXmlReport::s_bstrUt(L"ut");
const CComBSTR CXmlReport::s_bstrRunStatus(L"runstatus");
const CComBSTR CXmlReport::s_bstrDuration(L"duration");
const CComBSTR CXmlReport::s_bstrReport(L"report");

CXmlReport::CXmlReport(void)
{
}

CXmlReport::~CXmlReport(void)
{
	End();
}

void CXmlReport::Start(EFilter eFilter)
{
	DeleteFileW(g_csUtProjCommandLineParser.GetOutputPath());

	IXMLDOMElementPtr spTestRun;

	if (FAILED(m_spDocument.CreateInstance(CLSID_DOMDocument)) ||
		FAILED(m_spDocument->createElement(CComBSTR(L"testrun"), &spTestRun)) ||
		FAILED(spTestRun->setAttribute(CComBSTR(L"filter"), CComVariant(GetFilterName(eFilter)))) ||
		FAILED(spTestRun->setAttribute(CComBSTR(L"commandline"), CComVariant(GetCommandLine()))) ||
		FAILED(spTestRun->setAttribute(CComBSTR(L"started"), CComVariant(CTime::GetCurrentTime().Format(_T("%x %X"))))) ||
		FAILED(m_spDocument->appendChild(spTestRun, NULL)))
	{
		m_spDocument = NULL;
	}
}

void CXmlReport::GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam)
{
	if (m_spDocument)
	{
		IXMLDOMElementPtr spTestRun;
		IXMLDOMElementPtr spGroup;

		if (FAILED(m_spDocument->createElement(s_bstrGroup, &spGroup)) ||
			FAILED(spGroup->setAttribute(s_bstrName, CComVariant(lpGroupName))) ||
			FAILED(m_spDocument->get_documentElement(&spTestRun)) ||
			FAILED(spTestRun->appendChild(spGroup, NULL)))
		{
			m_spDocument = NULL;
		}
	}
}

void CXmlReport::TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam)
{
	
}

void CXmlReport::TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam)
{
	if (m_spDocument)
	{
		IXMLDOMElementPtr spTestRun;
		IXMLDOMNodePtr spNode;
		IXMLDOMElementPtr spGroup;
		IXMLDOMElementPtr spUt;
		CAtlStringW wstr;
		wstr.Format(L"group[@name=\"%s\"]", lpGroupName);

		if (FAILED(m_spDocument->get_documentElement(&spTestRun)) ||
			FAILED(spTestRun->selectSingleNode(CComBSTR(wstr), &spNode)) ||
			((spGroup = spNode) == NULL) ||
			FAILED(m_spDocument->createElement(s_bstrUt, &spUt)) ||
			FAILED(spUt->setAttribute(s_bstrName, CComVariant(lpTestName))) ||
			FAILED(spUt->setAttribute(s_bstrRunStatus, CComVariant(GetRunStatusName(eRunStatus)))) ||
			FAILED(spUt->setAttribute(s_bstrReport, CComVariant(lpReport))) ||
			FAILED(spUt->setAttribute(s_bstrDuration, CComVariant(tDuration))) ||
			FAILED(spGroup->appendChild(spUt, NULL)))
		{
			m_spDocument = NULL;
		}
	}
}

void CXmlReport::GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam)
{
	if (m_spDocument)
	{
		IXMLDOMElementPtr spTestRun;
		IXMLDOMNodePtr spNode;
		IXMLDOMElementPtr spGroup;
		CAtlStringW wstr;
		wstr.Format(L"group[@name=\"%s\"]", lpGroupName);

		if (FAILED(m_spDocument->get_documentElement(&spTestRun)) ||
			FAILED(spTestRun->selectSingleNode(CComBSTR(wstr), &spNode)) ||
			((spGroup = spNode) == NULL) ||
			FAILED(spGroup->setAttribute(s_bstrRunStatus, CComVariant(GetRunStatusName(eRunStatus)))) ||
			FAILED(spGroup->setAttribute(s_bstrReport, CComVariant(lpReport))) ||
			FAILED(spGroup->setAttribute(s_bstrDuration, CComVariant(tDuration))))
		{
			m_spDocument = NULL;
		}
	}
}

void CXmlReport::End()
{
	if (m_spDocument)
	{
		IXMLDOMElementPtr spTestRun;
		if (SUCCEEDED(m_spDocument->get_documentElement(&spTestRun)) &&
			SUCCEEDED(spTestRun->setAttribute(CComBSTR(L"ended"), CComVariant(CTime::GetCurrentTime().Format(_T("%x %X"))))))
		{
			m_spDocument->save(CComVariant(g_csUtProjCommandLineParser.GetOutputPath()));
		}
	}

	m_spDocument = NULL;
}
