#include "stdafx.h"
#include "ReportBuilder.h"

CReportBuilder::CReportBuilder(void)
{
}

CReportBuilder::~CReportBuilder(void)
{
}

void CReportBuilder::Subscribe(IReportNotification * p)
{
	m_aSubscribers.Add(p);
}

void CReportBuilder::Unsubscribe(IReportNotification * p)
{
	for (size_t t = 0; t < m_aSubscribers.GetCount(); ++t)
	{
		if (m_aSubscribers.GetAt(t) == p)
		{
			m_aSubscribers.RemoveAt(t);
			break;
		}
	}
}

void CReportBuilder::Start(EFilter eFilter)
{
	for (size_t t = 0; t < m_aSubscribers.GetCount(); ++t)
	{
		m_aSubscribers.GetAt(t)->Start(eFilter);
	}
}

void CReportBuilder::GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam)
{
	for (size_t t = 0; t < m_aSubscribers.GetCount(); ++t)
	{
		m_aSubscribers.GetAt(t)->GroupStart(lpGroupName, nGroupParam);
	}
}

void CReportBuilder::TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam)
{
	for (size_t t = 0; t < m_aSubscribers.GetCount(); ++t)
	{
		m_aSubscribers.GetAt(t)->TestStart(lpGroupName, lpTestName, nGroupParam, nTestParam);
	}
}

void CReportBuilder::TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam)
{
	for (size_t t = 0; t < m_aSubscribers.GetCount(); ++t)
	{
		m_aSubscribers.GetAt(t)->TestEnd(lpGroupName, lpTestName, eRunStatus, lpReport, tDuration, nGroupParam, nTestParam);
	}
}

void CReportBuilder::GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam)
{
	for (size_t t = 0; t < m_aSubscribers.GetCount(); ++t)
	{
		m_aSubscribers.GetAt(t)->GroupEnd(lpGroupName, eRunStatus, lpReport, tDuration, nGroupParam);
	}
}

void CReportBuilder::End()
{
	for (size_t t = 0; t < m_aSubscribers.GetCount(); ++t)
	{
		m_aSubscribers.GetAt(t)->End();
	}
}