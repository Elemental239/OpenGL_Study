#ifndef __IREPORTNOTIFICATION_H__
#define __IREPORTNOTIFICATION_H__

#include "..\Common.h"

//defines possible filters/sorters for a test set
enum EFilter
{
	efNone,
	efFile,
	efInteractive
};

inline LPCWSTR GetFilterName(EFilter eFilter)
{
	switch(eFilter)
	{
	case efNone: return L"none";
	case efFile: return L"file";
	case efInteractive: return L"interactive";
	default:
		ATLASSERT(!"no matches");
	}
	return L"";
};

//defines interface for a test run subscribers
__interface IReportNotification
{
	void Start(EFilter eFilter);
	void GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam);
	void TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam);
	void TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam);
	void GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam);
	void End();
};

#endif