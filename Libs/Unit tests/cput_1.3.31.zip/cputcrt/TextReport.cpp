#include "StdAfx.h"
#include "TextReport.h"

CTextReport::CTextReport(void)
{
}

CTextReport::~CTextReport(void)
{
}

void CTextReport::Start(EFilter eFilter)
{
	_putts(_T("Unit Test Run"));
	_tprintf_s(_T("Command Line : %s\r\nStarted : %s\r\n"),
		GetCommandLine(),
		CTime::GetCurrentTime().Format(_T("%x %X")));

	wprintf_s(L"Filter : %s\r\n\r\n", GetFilterName(eFilter));
}

void CTextReport::GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam)
{
	wprintf_s(L"The %s test group has started\r\n", lpGroupName);
}

void CTextReport::TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam)
{
	wprintf_s(L"\tThe %s::%s test ", lpGroupName, lpTestName);
}

void CTextReport::TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam)
{
	CTimeSpan tmDuration(tDuration);
	wprintf_s(L"finished, status %s, time %I64i second(s)", GetRunStatusName(eRunStatus), tmDuration.GetTotalSeconds()); 
	if (wcslen(lpReport))
		wprintf_s(L"report %s\r\n", lpReport);
	else
		_putws(L"");
}

void CTextReport::GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam)
{
	CTimeSpan tmDuration(tDuration);
	wprintf_s(L"The %s test group has finished, status %s, time %I64i second(s)", lpGroupName, GetRunStatusName(eRunStatus), tmDuration.GetTotalSeconds()); 
	if (wcslen(lpReport))
		wprintf_s(L"report %s\r\n", lpReport);
	else
		_putws(L"");
}

void CTextReport::End()
{
	_tprintf_s(_T("Ended : %s\r\n"), CTime::GetCurrentTime().Format(_T("%x %X")));
}

