#pragma once
#include "IReportNotification.h"

/**********************************************************************************
Xml output file report format:

<testrun filter="none | file | interactive" 
	commandline="<command line>" 
	started="data time of starting test run" 
	ended=" data time of ending test run ">

	<group name="<test group name>" 
		runstatus="<status>" 
		report="<test group execution report>" 
		duration="< test group time duration>">
		
		<ut name="<unit name>" 
			runstatus="<status>" 
			report="<unit test execution report>" 
			duration=" unit test time duration "/>
		...
	</group>
	...
</testrun>

<test group time duration> - time given in __time64_t,
<unit test time duration> - time given in __time64_t.

**********************************************************************************/


class CXmlReport : public IReportNotification
{
	//xml report container document
	IXMLDOMDocumentPtr m_spDocument;

	//common constant
	const static CComBSTR s_bstrGroup;
	const static CComBSTR s_bstrName;
	const static CComBSTR s_bstrUt;
	const static CComBSTR s_bstrRunStatus;
	const static CComBSTR s_bstrDuration;
	const static CComBSTR s_bstrReport;
public:
	CXmlReport(void);
	~CXmlReport(void);
	//IReportNotification
	void Start(EFilter eFilter);
	void GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam);
	void TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam);
	void TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam);
	void GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam);
	void End();
};
