#pragma once

/*******************************************************************************
There are two applications that take part in data exchange: a test running application 
and an IDE (devenv.exe with cput add-in). The data exchange uses a notification window 
message that has to be handled in the add-in�s Test running window, a memory map file 
to exchange data in both direction and has the following protocol:

1)	Synchronization of object names step. On which the test running application defines
	if it is under supervision of the IDE and tries to find the add-in�s Test running 
	window. Than it notifies it and gives its process id. 
	So names of synchronization object has the next format:

	Event name - "cputaddin_<IDE process id>"
	Memory map file name - "cputaddin_<IDE process id>< test app process id>"
	Process ids are given in dec format.

2)	Test set step. The test application creates a memory map file, fills a test set of all possible.
	The cput add-in synchronize itself with the given test set and defines if a test
	group or a unit test has to be executed and if so the addition (sort index) parameter of it.
	The defined test set is placed in the memory map file.

3)	Test group start notification step. Notify the IDE that a test group is about to 
	be created. The test group is identified by its sort index parameter in the test 
	set defined on the test set step. The step is optional. If there is no test group to 
	execute the step is omitted and the next step is the end notification.

4)	Test start notification step. Notify the IDE that a unit test is about to be executed. 
	The unit test is identified by its sort index parameter and the sort index of the 
	test group. The step is optional. If there is no unit test in the test group to execute 
	the next step will be the group end notification.

5)	Test end notification step. Notify the IDE that the unit test has been executed. 
	If there is more tests in group next step will be the test start notification. 
	If there is no more tests the next step will be the group end notification.

6)	Group end notification step. Notify the IDE that the test group has been executed. 
	If there is more test groups the next step will be the test group start notification. 
	If there is no more test groups the next step will be the end notification.

7)	End notification. Notify the IDE that the test set has been executed. On this step 
	the memory file and the synchronization event are closed.

Every step initiated on the test application side and notifies the IDE throw the window message. 
The IDE process message and confirms by setting the synchronization event. The test application 
waits the confirmation and can stop working witxxh the IDE if there in no response in 5 seconds.

The memory map file can be accessed by the IDE between receiving notification from the test 
application and setting the synchronization event.

*******************************************************************************/

#include "..\Common.h"
#include "..\TransData.h"
#include "IReportNotification.h"


class CTestRunnerExchange2 : public IReportNotification
{
ut_private:

	static const int c_nTimeout = 500000;

	BOOL	m_bConnected;
	CHandle	m_hEvent;
	CHandle m_hMmf;
	HWND	m_hTestRunnerWnd;
	DWORD	m_nMmfSize;

	wchar_t m_wsz[30];

public:
	CTestRunnerExchange2(void);
	~CTestRunnerExchange2(void);

	inline BOOL IsConnected() const { return m_bConnected; }

	//IReportNotification
	void Start(EFilter eFilter);
	void GroupStart(LPCWSTR lpGroupName, DWORD nGroupParam);
	void TestStart(LPCWSTR lpGroupName, LPCWSTR lpTestName, DWORD nGroupParam, DWORD nTestParam);
	void TestEnd(LPCWSTR lpGroupName, LPCWSTR lpTestName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam, DWORD nTestParam);
	void GroupEnd(LPCWSTR lpGroupName, ERunStatus eRunStatus, LPCWSTR lpReport, __time64_t tDuration, DWORD nGroupParam);
	void End();

	void Dispose();

	BOOL DefineTestsToRun(TestPackTransData & rTestPackTransData);

ut_private:
	BOOL NotifyServer(ETestRunExchangeStep step, LPARAM lParam = 0);

	//finds in the process tree a devenv process that launch the current application
	//returns the process id if have succeeded or 0xFFFFFFFF otherwise
	static DWORD DefineDebuggerProcId();

	#pragma region Find a test runner window functions
	//-------------------------------------------------------------------------
	struct SEnumWndParams
	{
		DWORD	dwProcId; //the input parameter that is used to check if an enumerated window belongs to the defined process
		HWND	hWnd;	//the output parameter that store the found window
	};

	static BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);

	//finds the TestRunner window in the process with dwProcId id
	static HWND FindTestRunnerWnd(DWORD dwProcId);

	static BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam);

	//recursively enumerates windows descending in a hierarchy three
	static void FindTestRunnerWnd(HWND hwnd, SEnumWndParams * pParams);
	//-------------------------------------------------------------------------
	#pragma endregion

};
