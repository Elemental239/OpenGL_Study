/************************************************************************************************
This header is used to store common intercases, enumeration for the cputlib (client side) and
the cput addin (server side)
************************************************************************************************/

#ifndef __COMMON_H__
#define __COMMON_H__

#pragma once

//defines possible statuses for tests and groups
enum ERunStatus
{
	Pending			= 0,
	Running			= 1,
	Stopped			= 2,
	Warning			= 3,
	Inconclusive	= 4,
	Succeeded		= 5,
	Failed			= 6,

	None			= 1024
};

inline LPCWSTR GetRunStatusName(ERunStatus eRunStatus)
{
	switch(eRunStatus)
	{
	case Pending:
		return L"Pending";
	case Running:
		return L"Running";
	case Stopped:
		return L"Stopped";
	case Warning:
		return L"Warning";
	case Inconclusive:
		return L"Inconclusive";
	case Succeeded:
		return L"Succeeded";
	case Failed:
		return L"Failed";
	case None:
		return L"";
	default:
		ATLASSERT(!"no matches");
	}
	return L"";
};

enum ETestRunExchangeStep
{
	stepStartNotification = 0,
	stepTestSet,
	stepGroupStartNotification,
	stepTestStartNotification,
	stepTestEndNotification,
	stepGroupEndNotification,
	stepEndNotification
};

//window text for a test runner window
const wchar_t c_wsz_TestRunner_[] = L"_TestRunner_";

//defines the window's message id for the _TestRunner_ window that notify about change in an exchange buffer,
//WPARAM is id of the client process, LPARAM is an address to the exchange buffer
#define WM_TESTAPPNOTIFY		(WM_USER + 1)

//defines the window's message id for the _TestRunner_ window that notify about a client process termination,
//WPARAM is a wait function return code, LPARAM is the client process exit code
#define WM_MONITORTHREADNOTIFY		(WM_USER + 2)

#endif __COMMON_H__
