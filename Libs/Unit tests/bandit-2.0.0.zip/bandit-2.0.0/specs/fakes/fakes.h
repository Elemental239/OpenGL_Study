#ifndef BANDIT_SPECS_FAKES_H
#define BANDIT_SPECS_FAKES_H

#include <specs/fakes/logging_fake.h>
#include <specs/fakes/fake_reporter.h>
#include <specs/fakes/fake_context.h>

#endif
