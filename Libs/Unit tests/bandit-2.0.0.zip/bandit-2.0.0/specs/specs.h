#ifndef BANDIT_SPECS
#define BANDIT_SPECS

#include <bandit/bandit.h>
using namespace bandit;

#include <specs/fakes/fakes.h>
#include <specs/util/util.h>

#endif
