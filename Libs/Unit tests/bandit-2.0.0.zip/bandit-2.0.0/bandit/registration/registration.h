#ifndef BANDIT_REGISTRATION_H
#define BANDIT_REGISTRATION_H

#include <bandit/registration/spec_registry.h>
#include <bandit/registration/registrar.h>

#endif
