#ifndef BANDIT_SKIP_POLICIES
#define BANDIT_SKIP_POLICIES

#include <bandit/skip_policies/skip_policy.h>
#include <bandit/skip_policies/always_include_policy.h>
#include <bandit/skip_policies/always_skip_policy.h>
#include <bandit/skip_policies/name_contains_skip_policy.h>

#endif
